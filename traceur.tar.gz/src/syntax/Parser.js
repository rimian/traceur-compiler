// Copyright 2012 Traceur Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {FindVisitor} from '../codegeneration/FindVisitor.js';
import {IdentifierToken} from './IdentifierToken.js';
import {
  ARRAY_LITERAL_EXPRESSION,
  BINDING_IDENTIFIER,
  CALL_EXPRESSION,
  COMPUTED_PROPERTY_NAME,
  COVER_FORMALS,
  FORMAL_PARAMETER_LIST,
  IDENTIFIER_EXPRESSION,
  LITERAL_PROPERTY_NAME,
  OBJECT_LITERAL_EXPRESSION,
  REST_PARAMETER,
  SYNTAX_ERROR_TREE
} from './trees/ParseTreeType.js';
import {
  AS,
  ASYNC,
  AWAIT,
  FROM,
  GET,
  OF,
  SET
} from './PredefinedName.js';
import {SyntaxErrorReporter} from '../util/SyntaxErrorReporter.js';
import {Scanner} from './Scanner.js';
import {SourceRange} from '../util/SourceRange.js';
import {StrictParams} from '../staticsemantics/StrictParams.js';
import {
  Token,
  isAssignmentOperator
} from './Token.js';
import {getKeywordType} from './Keywords.js';
import {options as traceurOptions} from '../Options.js';

import {
  AMPERSAND,
  AND,
  ARROW,
  AT,
  BANG,
  BAR,
  BREAK,
  CARET,
  CASE,
  CATCH,
  CLASS,
  CLOSE_ANGLE,
  CLOSE_CURLY,
  CLOSE_PAREN,
  CLOSE_SQUARE,
  COLON,
  COMMA,
  CONST,
  CONTINUE,
  DEBUGGER,
  DEFAULT,
  DELETE,
  DO,
  DOT_DOT_DOT,
  ELSE,
  END_OF_FILE,
  EQUAL,
  EQUAL_EQUAL,
  EQUAL_EQUAL_EQUAL,
  ERROR,
  EXPORT,
  EXTENDS,
  FALSE,
  FINALLY,
  FOR,
  FUNCTION,
  GREATER_EQUAL,
  IDENTIFIER,
  IF,
  IMPLEMENTS,
  IMPORT,
  IN,
  INSTANCEOF,
  INTERFACE,
  LEFT_SHIFT,
  LESS_EQUAL,
  LET,
  MINUS,
  MINUS_MINUS,
  NEW,
  NO_SUBSTITUTION_TEMPLATE,
  NOT_EQUAL,
  NOT_EQUAL_EQUAL,
  NULL,
  NUMBER,
  OPEN_ANGLE,
  OPEN_CURLY,
  OPEN_PAREN,
  OPEN_SQUARE,
  OR,
  PACKAGE,
  PERCENT,
  PERIOD,
  PLUS,
  PLUS_PLUS,
  PRIVATE,
  PROTECTED,
  PUBLIC,
  QUESTION,
  RETURN,
  RIGHT_SHIFT,
  SEMI_COLON,
  SLASH,
  SLASH_EQUAL,
  STAR,
  STAR_STAR,
  STATIC,
  STRING,
  SUPER,
  SWITCH,
  TEMPLATE_HEAD,
  TEMPLATE_TAIL,
  THIS,
  THROW,
  TILDE,
  TRUE,
  TRY,
  TYPEOF,
  UNSIGNED_RIGHT_SHIFT,
  VAR,
  VOID,
  WHILE,
  WITH,
  YIELD
} from './TokenType.js';

import {
  ArgumentList,
  ArrayComprehension,
  ArrayLiteralExpression,
  ArrayPattern,
  ArrayType,
  ArrowFunctionExpression,
  AssignmentElement,
  AwaitExpression,
  BinaryExpression,
  BindingElement,
  BindingIdentifier,
  Block,
  BreakStatement,
  CallExpression,
  CallSignature,
  CaseClause,
  Catch,
  ClassDeclaration,
  ClassExpression,
  CommaExpression,
  ComprehensionFor,
  ComprehensionIf,
  ComputedPropertyName,
  ConditionalExpression,
  ConstructSignature,
  ConstructorType,
  ContinueStatement,
  CoverFormals,
  CoverInitializedName,
  DebuggerStatement,
  Annotation,
  DefaultClause,
  DoWhileStatement,
  EmptyStatement,
  ExportDeclaration,
  ExportDefault,
  ExportSpecifier,
  ExportSpecifierSet,
  ExportStar,
  ExpressionStatement,
  Finally,
  ForInStatement,
  ForOfStatement,
  ForStatement,
  FormalParameter,
  FormalParameterList,
  FunctionBody,
  FunctionDeclaration,
  FunctionExpression,
  FunctionType,
  GeneratorComprehension,
  GetAccessor,
  IdentifierExpression,
  IfStatement,
  ImportDeclaration,
  ImportSpecifier,
  ImportSpecifierSet,
  ImportedBinding,
  IndexSignature,
  InterfaceDeclaration,
  LabelledStatement,
  LiteralExpression,
  LiteralPropertyName,
  MemberExpression,
  MemberLookupExpression,
  MethodSignature,
  Module,
  ModuleDeclaration,
  ModuleSpecifier,
  NamedExport,
  NewExpression,
  ObjectLiteralExpression,
  ObjectPattern,
  ObjectPatternField,
  ObjectType,
  ParenExpression,
  PostfixExpression,
  PredefinedType,
  PropertyMethodAssignment,
  PropertyNameAssignment,
  PropertyNameShorthand,
  PropertySignature,
  PropertyVariableDeclaration,
  RestParameter,
  ReturnStatement,
  Script,
  SetAccessor,
  SpreadExpression,
  SpreadPatternElement,
  SuperExpression,
  SwitchStatement,
  SyntaxErrorTree,
  TemplateLiteralExpression,
  TemplateLiteralPortion,
  TemplateSubstitution,
  ThisExpression,
  ThrowStatement,
  TryStatement,
  TypeArguments,
  TypeName,
  TypeParameter,
  TypeParameters,
  TypeReference,
  UnaryExpression,
  UnionType,
  VariableDeclaration,
  VariableDeclarationList,
  VariableStatement,
  WhileStatement,
  WithStatement,
  YieldExpression
}  from './trees/ParseTrees.js';

/**
 * Differentiates between parsing for 'In' vs. 'NoIn'
 * Variants of expression grammars.
 */
var Expression = {
  NO_IN: 'NO_IN',
  NORMAL: 'NORMAL'
};

/**
 * Enum for determining if the initializer is needed in a variable declaration
 * with a destructuring pattern.
 * @enum {string}
 */
var DestructuringInitializer = {
  REQUIRED: 'REQUIRED',
  OPTIONAL: 'OPTIONAL'
};

/**
 * Enum used to determine if an initializer is allowed or not.
 * @enum {string}
 */
var Initializer = {
  ALLOWED: 'ALLOWED',
  REQUIRED: 'REQUIRED'
};

/**
 * Used to find invalid CoverInitializedName trees. This is used when we know
 * the tree is not going to be used as a pattern.
 */
class ValidateObjectLiteral extends FindVisitor {
  constructor() {
    super();
    this.errorToken = null;
  }

  visitCoverInitializedName(tree) {
    this.errorToken = tree.equalToken;
    this.found = true;
  }
}

/**
 * @param {Array.<VariableDeclaration>} declarations
 * @return {boolean}
 */
function containsInitializer(declarations) {
  return declarations.some((v) => v.initializer);
}

/**
 * Parses a javascript file.
 *
 * The various this.parseX_() methods never return null - even when parse errors
 * are encountered.Typically this.parseX_() will return a XTree ParseTree. Each
 * ParseTree that is created includes its source location. The typical pattern
 * for a this.parseX_() method is:
 *
 * XTree this.parseX_() {
 *   var start = this.getTreeStartLocation_();
 *   parse X grammar element and its children
 *   return new XTree(this.getTreeLocation_(start), children);
 * }
 *
 * this.parseX_() methods must consume at least 1 token - even in error cases.
 * This prevents infinite loops in the parser.
 *
 * Many this.parseX_() methods are matched by a 'boolean this.peekX_()' method
 * which will return true if the beginning of an X appears at the current
 * location. There are also this.peek_() methods which examine the next token.
 * this.peek_() methods must not consume any tokens.
 *
 * The this.eat_() method consumes a token and reports an error if the consumed
 * token is not of the expected type. The this.eatOpt_() methods consume the
 * next token iff the next token is of the expected type and return the consumed
 * token or null if no token was consumed.
 *
 * When parse errors are encountered, an error should be reported and the parse
 * should return a best guess at the current parse tree.
 *
 * When parsing lists, the preferred pattern is:
 *   this.eat_(LIST_START);
 *   var elements = [];
 *   while (this.peekListElement_()) {
 *     elements.push(this.parseListElement_());
 *   }
 *   this.eat_(LIST_END);
 */
export class Parser {
  /**
   * @param {SourceFile} file
   * @param {ErrorReporter} errorReporter
   * @param {Options} options
   */
  constructor(file, errorReporter = new SyntaxErrorReporter(),
              options = traceurOptions) {
    this.errorReporter_ = errorReporter;
    this.scanner_ = new Scanner(errorReporter, file, this, options);
    this.options_ = options;

    // yield is only allowed inside a generator and await is only allowed
    // inside an async function.
    this.allowYield = false;
    this.allowAwait = false;

    // This is used in conjunction with ensureNoCoverInitializedNames_ to
    // determine  if there has been any added CoverInitializedName since last
    // time this was read.
    this.coverInitializedNameCount_ = 0;

    /**
     * Keeps track of whether we are currently in strict mode parsing or not.
     */
    this.strictMode_ = false;

    this.annotations_ = [];
  }

  // 14 Script
  /**
   * @return {Script}
   */
  parseScript() {
    this.strictMode_ = false;
    var start = this.getTreeStartLocation_();
    var scriptItemList = this.parseStatementList_(true);
    this.eat_(END_OF_FILE);
    return new Script(this.getTreeLocation_(start), scriptItemList);
  }

  // StatementList :
  //   StatementListItem
  //   StatementList StatementListItem

  /**
   * @return {Array.<ParseTree>}
   * @private
   */
  parseStatementList_(checkUseStrictDirective) {
    var result = [];
    var type;

    // We do a lot of type assignment in loops like these for performance
    // reasons.
    while ((type = this.peekType_()) !== CLOSE_CURLY && type !== END_OF_FILE) {
      var statement = this.parseStatementListItem_(type);
      if (checkUseStrictDirective) {
        if (!statement.isDirectivePrologue()) {
          checkUseStrictDirective = false;
        } else if (statement.isUseStrictDirective()) {
          this.strictMode_ = true;
          checkUseStrictDirective = false;
        }
      }

      result.push(statement);
    }
    return result;
  }

  // ScriptItem :
  //   ModuleDeclaration
  //   ImportDeclaration
  //   StatementListItem

  /**
   * @return {ParseTree}
   * @private
   */
  parseStatementListItem_(type) {
    // TODO(arv): Split into Declaration and Statement
    return this.parseStatementWithType_(type);
  }

  parseModule() {
    var start = this.getTreeStartLocation_();
    var scriptItemList = this.parseModuleItemList_();
    this.eat_(END_OF_FILE);
    return new Module(this.getTreeLocation_(start), scriptItemList, null);
  }

  parseModuleItemList_() {
    this.strictMode_ = true;
    var result = [];
    var type;

    while ((type = this.peekType_()) !== END_OF_FILE) {
      var statement = this.parseModuleItem_(type);
      result.push(statement);
    }
    return result;
  }

  parseModuleItem_(type) {
    switch (type) {
      case IMPORT:
        return this.parseImportDeclaration_();
      case EXPORT:
        return this.parseExportDeclaration_();
      case AT:
        if (this.options_.annotations)
          return this.parseAnnotatedDeclarations_(true);
        break;
    }
    return this.parseStatementListItem_(type);
  }

  parseModuleSpecifier_() {
    // ModuleSpecifier :
    //   StringLiteral
    var start = this.getTreeStartLocation_();
    var token = this.eat_(STRING);
    return new ModuleSpecifier(this.getTreeLocation_(start), token);
  }

  // ClassDeclaration
  // ImportDeclaration
  // ExportDeclaration
  // ModuleDeclaration
  // TODO: ModuleBlock
  // Statement (other than BlockStatement)
  // FunctionDeclaration

  // ImportDeclaration ::= "import" ImportDeclaration
  /**
   * @return {ParseTree}
   * @private
   */
  parseImportDeclaration_() {
    var start = this.getTreeStartLocation_();
    this.eat_(IMPORT);

    // import * as m from './m.js'
    if (this.peek_(STAR)) {
      this.eat_(STAR);
      this.eatId_(AS);
      var binding = this.parseImportedBinding_();
      this.eatId_(FROM);
      var moduleSpecifier = this.parseModuleSpecifier_();
      this.eatPossibleImplicitSemiColon_();
      return new ModuleDeclaration(this.getTreeLocation_(start), binding,
                                   moduleSpecifier);
    }

    var importClause = null;
    if (this.peekImportClause_(this.peekType_())) {
      importClause = this.parseImportClause_();
      this.eatId_(FROM);
    }
    var moduleSpecifier = this.parseModuleSpecifier_();
    this.eatPossibleImplicitSemiColon_();
    return new ImportDeclaration(this.getTreeLocation_(start),
        importClause, moduleSpecifier);
  }

  peekImportClause_(type) {
    return type === OPEN_CURLY || this.peekBindingIdentifier_(type);
  }

  // https://bugs.ecmascript.org/show_bug.cgi?id=2287
  // ImportClause :
  //   ImportedBinding
  //   NamedImports

  parseImportClause_() {
    var start = this.getTreeStartLocation_();
    if (this.eatIf_(OPEN_CURLY)) {
      var specifiers = [];
      while (!this.peek_(CLOSE_CURLY) && !this.isAtEnd()) {
        specifiers.push(this.parseImportSpecifier_());
        if (!this.eatIf_(COMMA))
          break;
      }
      this.eat_(CLOSE_CURLY);

      return new ImportSpecifierSet(this.getTreeLocation_(start), specifiers);
    }

    return this.parseImportedBinding_();
  }

  parseImportedBinding_() {
    var start = this.getTreeStartLocation_();
    var binding = this.parseBindingIdentifier_();
    return new ImportedBinding(this.getTreeLocation_(start), binding);
  }

  // ImportSpecifier ::= IdentifierName ("as" Identifier)?
  //                     Identifier "as" Identifier
  /**
   * @return {ParseTree}
   * @private
   */
  parseImportSpecifier_() {
    var start = this.getTreeStartLocation_();
    var token = this.peekToken_();
    var isKeyword = token.isKeyword();
    var binding;
    var name = this.eatIdName_();
    if (isKeyword || this.peekPredefinedString_(AS)) {
      this.eatId_(AS);
      binding = this.parseImportedBinding_();
    } else {
      binding = new ImportedBinding(name.location,
          new BindingIdentifier(name.location, name));
      name = null;
    }
    return new ImportSpecifier(this.getTreeLocation_(start), binding, name);
  }

  // export  VariableStatement
  // export  FunctionDeclaration
  // export  ConstStatement
  // export  ClassDeclaration
  // export  ModuleDeclaration

  /**
   * @return {ParseTree}
   * @private
   */
  parseExportDeclaration_() {
    var start = this.getTreeStartLocation_();
    this.eat_(EXPORT);
    var exportTree;
    var annotations = this.popAnnotations_();
    var type = this.peekType_();
    switch (type) {
      case CONST:
      case LET:
      case VAR:
        exportTree = this.parseVariableStatement_();
        break;
      case FUNCTION:
        exportTree = this.parseFunctionDeclaration_();
        break;
      case CLASS:
        exportTree = this.parseClassDeclaration_();
        break;
      case DEFAULT:
        exportTree = this.parseExportDefault_();
        break;
      case OPEN_CURLY:
      case STAR:
        exportTree = this.parseNamedExport_();
        break;
      case IDENTIFIER:
        if (this.options_.asyncFunctions && this.peekPredefinedString_(ASYNC)) {
          var asyncToken = this.eatId_();
          exportTree = this.parseAsyncFunctionDeclaration_(asyncToken);
          break;
        }
        // Fall through.
      default:
        return this.parseUnexpectedToken_(type);
    }
    return new ExportDeclaration(this.getTreeLocation_(start), exportTree,
                                 annotations);
  }

  parseExportDefault_() {
    // export default AssignmentExpression ;
    var start = this.getTreeStartLocation_();
    this.eat_(DEFAULT);
    var exportValue;
    switch (this.peekType_()) {
      case FUNCTION:
        // Use FunctionExpression as a cover grammar. If it has a name it is
        // treated as a declaration.
        var tree = this.parseFunctionExpression_();
        if (tree.name) {
          tree = new FunctionDeclaration(tree.location, tree.name,
                                         tree.functionKind, tree.parameterList,
                                         tree.typeAnnotation, tree.annotations,
                                         tree.body);
        }
        exportValue = tree;
        break;
      case CLASS:
        if (this.options_.classes) {
          // Use ClassExpression as a cover grammar. If it has a name it is
          // treated as a declaration.
          var tree = this.parseClassExpression_();
          if (tree.name) {
            tree = new ClassDeclaration(tree.location, tree.name,
                                        tree.superClass, tree.elements,
                                        tree.annotations);
          }
          exportValue = tree;
          break;
        }
        // Fall through.
      default:
        exportValue = this.parseAssignmentExpression();
        this.eatPossibleImplicitSemiColon_();
    }

    return new ExportDefault(this.getTreeLocation_(start), exportValue);
  }

  parseNamedExport_() {
    // NamedExport ::=
    //     "*" "from" ModuleSpecifier(load)
    //     ExportSpecifierSet ("from" ModuleSpecifier(load))?
    var start = this.getTreeStartLocation_();

    var specifierSet, expression = null;

    if (this.peek_(OPEN_CURLY)) {
      specifierSet = this.parseExportSpecifierSet_();
      if (this.peekPredefinedString_(FROM)) {
        this.eatId_(FROM);
        expression = this.parseModuleSpecifier_();
      } else {
        // Ensure that the bindings (lhs) of the specifiers are not keywords.
        // Keywords are only disallowed when we do not have a 'from' following
        // the ExportSpecifierSet.
        this.validateExportSpecifierSet_(specifierSet);
      }
    } else {
      this.eat_(STAR);
      specifierSet = new ExportStar(this.getTreeLocation_(start));
      this.eatId_(FROM);
      expression = this.parseModuleSpecifier_();
    }

    this.eatPossibleImplicitSemiColon_();

    return new NamedExport(this.getTreeLocation_(start), expression,
                             specifierSet);
  }

  parseExportSpecifierSet_() {
    // ExportSpecifierSet ::=
    //     "{" ExportSpecifier ("," ExportSpecifier)* ","? "}"

    var start = this.getTreeStartLocation_();
    this.eat_(OPEN_CURLY);
    var specifiers = [this.parseExportSpecifier_()];
    while (this.eatIf_(COMMA)) {
      if (this.peek_(CLOSE_CURLY))
        break;
      specifiers.push(this.parseExportSpecifier_());
    }
    this.eat_(CLOSE_CURLY);

    return new ExportSpecifierSet(this.getTreeLocation_(start), specifiers);
  }

  // ExportSpecifier :
  //   Identifier
  //   Identifier "as" IdentifierName
  parseExportSpecifier_() {
    // ExportSpecifier ::= IdentifierName
    //     | IdentifierName "as" IdentifierName

    var start = this.getTreeStartLocation_();
    var lhs = this.eatIdName_();
    var rhs = null;
    if (this.peekPredefinedString_(AS)) {
      this.eatId_();
      rhs = this.eatIdName_();
    }
    return new ExportSpecifier(this.getTreeLocation_(start), lhs, rhs);
  }

  validateExportSpecifierSet_(tree) {
    for (var i = 0; i < tree.specifiers.length; i++) {
      var specifier = tree.specifiers[i];
      // These are represented as IdentifierTokens because we used eatIdName.
      if (getKeywordType(specifier.lhs.value)) {
        this.reportError_(specifier.lhs.location,
            `Unexpected token ${specifier.lhs.value}`);
      }
    }
  }

  peekId_(type) {
    if (type === IDENTIFIER)
      return true;
    if (this.strictMode_)
      return false;
    return this.peekToken_().isStrictKeyword();
  }

  peekIdName_(token) {
    return token.type === IDENTIFIER || token.isKeyword();
  }

  parseClassShared_(constr) {
    var start = this.getTreeStartLocation_();
    var strictMode = this.strictMode_;
    this.strictMode_ = true;
    this.eat_(CLASS);
    var name = null;
    var annotations = [];
    // Name is optional for ClassExpression
    if (constr == ClassDeclaration ||
        !this.peek_(EXTENDS) && !this.peek_(OPEN_CURLY)) {
      name = this.parseBindingIdentifier_();
      annotations = this.popAnnotations_();
    }
    var superClass = null;
    if (this.eatIf_(EXTENDS)) {
      superClass = this.parseAssignmentExpression();
    }
    this.eat_(OPEN_CURLY);
    var elements = this.parseClassElements_();
    this.eat_(CLOSE_CURLY);
    this.strictMode_ = strictMode;
    return new constr(this.getTreeLocation_(start), name, superClass,
                      elements, annotations);
  }

  /**
   * @return {ParseTree}
   * @private
   */
  parseClassDeclaration_() {
    return this.parseClassShared_(ClassDeclaration);
  }

  /**
   * @return {ParseTree}
   * @private
   */
  parseClassExpression_() {
    return this.parseClassShared_(ClassExpression);
  }

  /**
   * @return {Array.<ParseTree>}
   * @private
   */
  parseClassElements_() {
    var result = [];

    while (true) {
      var type = this.peekType_();
      if (type === SEMI_COLON) {
        this.nextToken_();
      } else if (this.peekClassElement_(this.peekType_())) {
        result.push(this.parseClassElement_());
      } else {
        break;
      }
    }

    return result;
  }

  peekClassElement_(type) {
    // PropertyName covers get, set and static too.
    return this.peekPropertyName_(type) ||
        type === STAR && this.options_.generators ||
        type === AT && this.options_.annotations;
  }

  // PropertyName :
  //   LiteralPropertyName
  //   ComputedPropertyName
  parsePropertyName_() {
    if (this.peek_(OPEN_SQUARE))
      return this.parseComputedPropertyName_()
    return this.parseLiteralPropertyName_();
  }

  parseLiteralPropertyName_() {
    var start = this.getTreeStartLocation_();
    var token = this.nextToken_();
    return new LiteralPropertyName(this.getTreeLocation_(start), token);
  }

  // ComputedPropertyName :
  //   [ AssignmentExpression ]
  parseComputedPropertyName_() {
    var start = this.getTreeStartLocation_();
    this.eat_(OPEN_SQUARE);
    var expression = this.parseAssignmentExpression();
    this.eat_(CLOSE_SQUARE);

    return new ComputedPropertyName(this.getTreeLocation_(start), expression);
  }

  /**
   * Parses a single statement. This statement might be a top level statement
   * in a Script or a Module as well as any other statement allowed in a
   * FunctionBody.
   * @return {ParseTree}
   */
  parseStatement() {
    return this.parseModuleItem_(this.peekType_());
  }

  /**
   * Parses one or more statements. These might be top level statements in a
   * Script or a Module as well as any other statement allowed in a
   * FunctionBody.
   * @return {Array.<ParseTree>}
   */
  parseStatements() {
    return this.parseModuleItemList_();
  }

  parseStatement_() {
    return this.parseStatementWithType_(this.peekType_());
  }

  /**
   * @return {ParseTree}
   * @private
   */
  parseStatementWithType_(type) {
    switch (type) {
      // Most common first (based on building Traceur).
      case RETURN:
        return this.parseReturnStatement_();
      case CONST:
      case LET:
        if (!this.options_.blockBinding)
          break;
        // Fall through.
      case VAR:
        return this.parseVariableStatement_();
      case IF:
        return this.parseIfStatement_();
      case FOR:
        return this.parseForStatement_();
      case BREAK:
        return this.parseBreakStatement_();
      case SWITCH:
        return this.parseSwitchStatement_();
      case THROW:
        return this.parseThrowStatement_();
      case WHILE:
        return this.parseWhileStatement_();
      case FUNCTION:
        return this.parseFunctionDeclaration_();

      // Rest are just alphabetical order.
      case AT:
        if (this.options_.annotations)
          return this.parseAnnotatedDeclarations_(false);
        break;
      case CLASS:
        if (this.options_.classes)
          return this.parseClassDeclaration_();
        break;
      case CONTINUE:
        return this.parseContinueStatement_();
      case DEBUGGER:
        return this.parseDebuggerStatement_();
      case DO:
        return this.parseDoWhileStatement_();
      case OPEN_CURLY:
        return this.parseBlock_();
      case SEMI_COLON:
        return this.parseEmptyStatement_();
      case TRY:
        return this.parseTryStatement_();
      case WITH:
        return this.parseWithStatement_();
      case INTERFACE:
        // TODO(arv): This should only be allowed at the top level.
        if (this.options_.types) {
          return this.parseInterfaceDeclaration_();
        }
    }
    return this.parseFallThroughStatement_();
  }

  // 13 Function Definition
  /**
   * @return {ParseTree}
   * @private
   */
  parseFunctionDeclaration_() {
    return this.parseFunction_(FunctionDeclaration);
  }

  /**
   * @return {ParseTree}
   * @private
   */
  parseFunctionExpression_() {
    return this.parseFunction_(FunctionExpression);
  }

  parseAsyncFunctionDeclaration_(asyncToken) {
    return this.parseAsyncFunction_(asyncToken, FunctionDeclaration);
  }

  parseAsyncFunctionExpression_(asyncToken) {
    return this.parseAsyncFunction_(asyncToken, FunctionExpression);
  }

  parseAsyncFunction_(asyncToken, ctor) {
    var start = asyncToken.location.start;
    this.eat_(FUNCTION);
    return this.parseFunction2_(start, asyncToken, ctor);
  }

  parseFunction_(ctor) {
    var start = this.getTreeStartLocation_();
    this.eat_(FUNCTION);
    var functionKind = null;
    if (this.options_.generators && this.peek_(STAR))
      functionKind = this.eat_(STAR);
    return this.parseFunction2_(start, functionKind, ctor);
  }

  parseFunction2_(start, functionKind, ctor) {
    var name = null;
    var annotations = [];
    if (ctor === FunctionDeclaration ||
        this.peekBindingIdentifier_(this.peekType_())) {
      name = this.parseBindingIdentifier_();
      annotations = this.popAnnotations_();
    }

    this.eat_(OPEN_PAREN);
    var parameters = this.parseFormalParameters_();
    this.eat_(CLOSE_PAREN);

    var typeAnnotation = this.parseTypeAnnotationOpt_();
    var body = this.parseFunctionBody_(functionKind, parameters);
    return new ctor(this.getTreeLocation_(start), name, functionKind,
                    parameters, typeAnnotation, annotations, body);
  }

  peekRest_(type) {
    return type === DOT_DOT_DOT && this.options_.restParameters;
  }

  /**
   * @return {FormalParameterList}
   * @private
   */
  parseFormalParameters_() {
    // FormalParameterList :
    //   [empty]
    //   FunctionRestParameter
    //   FormalsList
    //   FormalsList , FunctionRestParameter
    //
    // FunctionRestParameter :
    //   ... BindingIdentifier
    //
    // FormalsList :
    //   FormalParameter
    //   FormalsList , FormalParameter
    //
    // FormalParameter :
    //   BindingElement
    //
    // BindingElement :
    //   SingleNameBinding
    //   BindingPattern Initializeropt
    var start = this.getTreeStartLocation_();
    var formals = [];
    this.pushAnnotations_();
    var type = this.peekType_();
    if (this.peekRest_(type)) {
      formals.push(this.parseFormalRestParameter_());
    } else {
      if (this.peekFormalParameter_(this.peekType_()))
        formals.push(this.parseFormalParameter_());

      while (this.eatIf_(COMMA)) {
        this.pushAnnotations_();
        if (this.peekRest_(this.peekType_())) {
          formals.push(this.parseFormalRestParameter_());
          break;
        }
        formals.push(this.parseFormalParameter_());
      }
    }

    return new FormalParameterList(this.getTreeLocation_(start), formals);
  }

  peekFormalParameter_(type) {
    return this.peekBindingElement_(type);
  }

  parseFormalParameter_(initializerAllowed = undefined) {
    var start = this.getTreeStartLocation_();
    var binding = this.parseBindingElementBinding_();
    var typeAnnotation = this.parseTypeAnnotationOpt_();
    var initializer = this.parseBindingElementInitializer_(initializerAllowed);

    return new FormalParameter(this.getTreeLocation_(start),
        new BindingElement(this.getTreeLocation_(start), binding, initializer),
        typeAnnotation, this.popAnnotations_());
  }

  parseFormalRestParameter_() {
    var start = this.getTreeStartLocation_();
    var restParameter = this.parseRestParameter_();
    var typeAnnotation = this.parseTypeAnnotationOpt_();
    return new FormalParameter(this.getTreeLocation_(start), restParameter,
        typeAnnotation, this.popAnnotations_());
  }

  parseRestParameter_() {
    var start = this.getTreeStartLocation_();
    this.eat_(DOT_DOT_DOT);
    var id = this.parseBindingIdentifier_();
    var typeAnnotation = this.parseTypeAnnotationOpt_();
    return new RestParameter(this.getTreeLocation_(start), id, typeAnnotation);
  }

  /**
   * @return {Block}
   * @private
   */
  parseFunctionBody_(functionKind, params) {
    var start = this.getTreeStartLocation_();
    this.eat_(OPEN_CURLY);

    var allowYield = this.allowYield;
    var allowAwait = this.allowAwait;
    var strictMode = this.strictMode_;

    this.allowYield = functionKind && functionKind.type === STAR;
    this.allowAwait = functionKind &&
        functionKind.type === IDENTIFIER && functionKind.value === ASYNC;

    var result = this.parseStatementList_(!strictMode);

    if (!strictMode && this.strictMode_ && params)
      StrictParams.visit(params, this.errorReporter_);

    this.strictMode_ = strictMode;
    this.allowYield = allowYield;
    this.allowAwait = allowAwait;

    this.eat_(CLOSE_CURLY);
    return new FunctionBody(this.getTreeLocation_(start), result);
  }

  /**
   * @return {SpreadExpression}
   * @private
   */
  parseSpreadExpression_() {
    if (!this.options_.spread)
      return this.parseUnexpectedToken_(DOT_DOT_DOT);

    var start = this.getTreeStartLocation_();
    this.eat_(DOT_DOT_DOT);
    var operand = this.parseAssignmentExpression();
    return new SpreadExpression(this.getTreeLocation_(start), operand);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @private
   */
  parseBlock_() {
    var start = this.getTreeStartLocation_();
    this.eat_(OPEN_CURLY);
    var result = this.parseStatementList_(false);
    this.eat_(CLOSE_CURLY);
    return new Block(this.getTreeLocation_(start), result);
  }

  // 12.2 Variable Statement
  /**
   * @return {VariableStatement}
   * @private
   */
  parseVariableStatement_() {
    var start = this.getTreeStartLocation_();
    var declarations = this.parseVariableDeclarationList_();
    this.checkInitializers_(declarations);
    this.eatPossibleImplicitSemiColon_();
    return new VariableStatement(this.getTreeLocation_(start), declarations);
  }

  /**
   * @param {Expression=} expressionIn
   * @param {DestructuringInitializer} initializer Whether destructuring
   *     requires an initializer
   * @return {VariableDeclarationList}
   * @private
   */
  parseVariableDeclarationList_(
      expressionIn = Expression.NORMAL,
      initializer = DestructuringInitializer.REQUIRED) {
    var type = this.peekType_();

    switch (type) {
      case CONST:
      case LET:
        if (!this.options_.blockBinding)
          debugger;
      case VAR:
        this.nextToken_();
        break;
      default:
        throw Error('unreachable');
    }

    var start = this.getTreeStartLocation_();
    var declarations = [];

    declarations.push(this.parseVariableDeclaration_(type, expressionIn,
                                                     initializer));
    while (this.eatIf_(COMMA)) {
      declarations.push(this.parseVariableDeclaration_(type, expressionIn,
                                                       initializer));
    }
    return new VariableDeclarationList(
        this.getTreeLocation_(start), type, declarations);
  }

  /**
   * VariableDeclaration :
   *   BindingIdentifier Initializeropt
   *   BindingPattern Initializer
   *
   * VariableDeclarationNoIn :
   *   BindingIdentifier InitializerNoInopt
   *   BindingPattern InitializerNoIn
   *
   * @param {TokenType} binding
   * @param {Expression} expressionIn
   * @param {DestructuringInitializer=} initializer
   * @return {VariableDeclaration}
   * @private
   */
  parseVariableDeclaration_(binding, expressionIn,
                            initializer = DestructuringInitializer.REQUIRED) {
    var initRequired = initializer !== DestructuringInitializer.OPTIONAL;
    var start = this.getTreeStartLocation_();

    var lvalue;
    var typeAnnotation;
    if (this.peekPattern_(this.peekType_())) {
      lvalue = this.parseBindingPattern_();
      typeAnnotation = null;
    } else {
      lvalue = this.parseBindingIdentifier_();
      typeAnnotation = this.parseTypeAnnotationOpt_();
    }

    var initializer = null;
    if (this.peek_(EQUAL))
      initializer = this.parseInitializer_(expressionIn);
    else if (lvalue.isPattern() && initRequired)
      this.reportError_('destructuring must have an initializer');

    return new VariableDeclaration(this.getTreeLocation_(start), lvalue,
        typeAnnotation, initializer);
  }

  /**
   * @param {Expression} expressionIn
   * @return {ParseTree}
   * @private
   */
  parseInitializer_(expressionIn) {
    this.eat_(EQUAL)DOT_DOT_DOT && this.optseStrictDirective()) 
      case e
    var typethi.rseExpor.  Bindingreak;
      de& initRequctLiteral exeat_(C3ialize);
    return new Block(this.geY:
        retexport  ClassDeclaration
  // :
        return);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @privatesult = [];);
    this.check :
        retrSet);
      }
    } else {
      t_(CLOSE_CURLY);
    reeclaration,
  Expor|
  ImportSpecifie|functionKind, ctor)eter(this.getTreeLocation_(sta      return this.pars  /**
   * @return {VariableStatement}
   * @private
   *ingreak;
 rtDeclarat/ yiel[no ln X a

   _();]TAR;
    /   his.optseStricee = this.parseNamedExport_();
        break;
      case IDEYield = funcnotation = QUAL,
  E 1ause_() {
    vf (this.options_.asyncFunctions &&n_(ctor) {
 T*/
  parseImportSpeciNoLak;T

   _();sElements_() {
tor) {
 T*/
  initat_(Eld = funcncToken, FunctionDeclaration);        var asyncToken = t@return {Variables.eatId_on,
  FunctionExpres.parseBindingElementInitializer_(initiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiisyncToken = this.e_())) {
      ) {
    var start = thirClass = null;
    ihis.optse) {
    vafunctionKind.type ==_EXPRESSI[];

    whiion();
2,
  Impore
   */
  parse.optseStrictDirect = [];OMMA)) {
   _(start,T*/
  pa) {
    vafi; i++) {
     ;A)) {
   _(stThese migh  var start = this.gethis.options_
    var sta  ImportSpecifie
    var body = this.parseFunctionB.locater_(initiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiThese migeter_());
          br this.parseVariableDeclarationList_();
    this.checkeclaration,
  ExporignmentExpression();
    this.eat_(CLOSE_SQUARE);

 on();5    ;
    return new Block(this.ge       retuinitializer);
  }

  /**
   * f      return);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @privatIFock}
   * @private
   gIdentifier_();
c
  Commar start = thirClass = null;
   }

    this.eat_(OPEN_PAier_();
if importClause = nul= this.gethis.opti  supe BindingingIdentifier_();
      annotaLSE;OMMA)) {
 pe Bindingingause = nul= this.gethis.optication,
          f,
  ExporignmentExpression();
    this.ec
  Comma,
if impor, pe BindingSQUARE);

 on();6 It = ommaratement al);

 on();6.1mes ado-expres;
    return new Block(this.geotation, initializer);
  }

  /**
   *       return this.rameter,
        typeAnnotation, this.popAnnotations_());
  }

  );
    this.eat_(CLOSE_PAREN= this.gethis.opti());
  }

tatemock}
   * @private
   gIdentifier_();
c
  Commar start = thirClass = null;
   }

    this.eat_(OPEN_PAier_ this.parseVariableDeclarationList_();
    this.check       return th   return new FormalParameter(th For
c
  CommaSQUARE);

 on();6.2mes aexpres;
    return new Block(this.geotation, initializer);
  }

  /**
   *     return this.rameter,
        typeAnnotation, this.popAnnotations_());
  }

tatemock}
   * @private
   gIdentifier_();
c
  Commar start = thirClass = null;
   }

    this.eat_(OPEN_PAier_this.eat_(CLOSE_PAREN= this.gethis.opti this.check     return th   return new FormalParameter(tc
  Comma,
rt), name, fun on();6.3mes as.ea;
    return on();6.4mes as.e-ins;
    return new Block(this.geotation, initializer);
  }

  /**
   *IF:
        ret
    return this.parseFunction2_(start, asyncToken, ctor);
  }

ORock}
   * @private
   gIdentif   returns.getTreeStartLocation_();
    var formalsires an initializer
   * 
    this.pushAturnvres an riableStatement_() {
    var start = ther_(initiiirationList}
 _I E ializer = DestructuringInitialize= t@return throw Error('unreavres an r.ow Error('unements_() {
             );
  } > 1().i* @param {Array.<VariableDeclarat{
        this();
      case IF:
        TAR);
    vres an reter_());
 this.pare
   */
  parseClassElements_() {
    var rIN{
        this();
      case IF:In first (bas);
    vres an reter_());
 this.peekType_();
Of* 
    this.pushAthis();
      case IF:Of first (bas);
    vres an reter_());
 this.is.pushAth ons.eaThese mig:ents_(   else if new Variabl.classes) reeStartLocation_();
   vres an reter_());this();
      case IF:
        TAR);
    vres an reter_());
 ());
 this.) {
    var result = [];

    whiis();
      case IF:
        TAR);
    at_(END_Os.parseBindinas been any added CoverIn  */
  pas been any added CoverIniPAier_();
innotationOpt_();
    }
rationListnotatation;
  rationList}
 _I ock}
   .getTreeStartLocation_();
    vainnotationO.isLeftHandSi; rClass = nulYield = func
    var rINoken.isKeyworOf* 
    tY);
    varnnotationOpt_();
 trans_())LeftHandSi; rClass = ns.parseTypeAnlements_() {
 isKeyworOf* 
    ts.pushAthis();
      case IF:Of first (bas);
    parseTypeAnlements_(is();
      case IF:In first (bas);
    parseTypeAnlements     br this.Yield = false;
    this.allow.parseTypeAn,nas been any added CoverInrn() && initReq     case IF:
        TAR);
    new VariableDeclaratiyworOf* 
                    parametnd.type === STStricee = thisfF:OfYield = funcnotation 
      reallowAwaitOFname, fun ones as.e-VAR:a;
    return ons.ea (  { let |_();
}_()
   *   Bithis ) {
    var ) ssion);
  }

is.parseListElement_())rseComma}n thisparseListElemeotation, i binding
   * @param {Expreotation, initializer);
  }

  /**
   *IF:Of first (bas);
    parseTypeAnlssionIn
   * @rcFunctn onofrseBindinasmpocommar start = thirClass = null;
   }

    this.eat_(OPEN_PAier_this.eat_(CLOSE_PAREN= this.gethis.opti this.checkIF:Of first (b
    var typeAnnotation = this.parseTypeAn,er_(initiiiiiiiiiiiiiiiiiiiiiiiasmpocomma,
rt), name, fun s.parseLCrtLos vres an row Error('up levres an r    s.eaThese mig  } el.parseListElemezer} initializer Whether vres an r* @param {Exprevoidinitializer);
  }

  /**artLocation_();
   vres an re this.optseStricpeekType_();

    swiYield = funcvres an r.ow Error('uT paramitiali>}
   * @private
   *vres an r.ow Error('uT paements_(is.getTreeLocation_(vres an r.ow Error('uns);
  }

  validateExptype = this.artLocation_();
    whilvres an r.ow Error('un[i]COMMA)) {
     s.peekType_())) {
     specifier.lhs.l s.parseLCrtLos vres an row Error('u} el.parseListElemeIdentifier   whparseListElemezer} initializer Wh}row Error('u} el.ram {Exprents ah}r @param temernnotationOpi tokrsUse.nitializer);
  }

  /**artLocation_();
    whilow Error('ue this.optseStricpeekType_();

    swiYie   paramitialiYield = func ClassExpresrnnotationOptitat_(Er lhs = this.eitializer_(expnts_( vres an ri  else if (lvalue.isPattern(ents_(is();
    if (types.options_.typtTreeStt_(CLOSE_CURLY);
    rents ea)eter(this.getTreeLocationalsires an initializer
   * 
    ;
      result.push(statement);
  if (!this.options_.bl
        } ngInitializer.REQUIRED) {
    var tyinitReq     peekType_();

    swikBinding)
          debugis();
    if (types.op, fun on();6.3mes as.ea;
    return s.parseListElement_())rseComma}n thisparseListElemeotation, i binding
   * @param {Expreotation, initializer);
  }

  /**
   *IF:
        TAR);
    new VariablessionIn
   * @retesult = [];);fier_();
c
  Commar sIdentifier_();ClassExpressesult = [];(statement)
  Commar start = thirClass = null;
    if (this.eatIf_esult = [];);fier_();
incre migh  Identifier_();ClassExpresss.eat_(OPEN_Y);
    varncre migh  tart = thirClass = null;
    if (this.eatIf_s.eat_(OPEN_PAier_this.eat_(CLOSE_PAREN= this.gethis.opti this.checkIF: first (b
    var typeAnnotation = this.parseTypeAn,er_(initiiiiiiiiiiiiiiiiiiiiic
  Comma,
incre mig,
rt), name, fun on();6.4mes as.e-ins;
    return new BlockstElement_())rseComma}n thisparseListElemeotation, i binding
   * @param {Expreotation, initializer);
  }

  /**
   *IF:In first (bas);
    parseTypeAnlssionIn
   * @retIntifier_();
c
mpocommar start = thirClass = null;
   }

    this.eat_(OPEN_PAier_this.eat_(CLOSE_PAREN= this.gethis.opti this.checkIF:In,
  ExporignmentExpression();
    this.eparseTypeAn,er_(initiiiiiiiiiiiiiiiiiiiiiiiasmpocomma,
rt), name, fun on();7mes acrseClass;
    return new Block(this.geotation, initializer);
  }

  /**
   *arseClassDeclaration
    return this.parseFunction2_(start, asyncToken, ctor);
  }
s_.class_PAier_thisart, functionKind_();ClassExprebleDeclarationList_eStartLocation_();

    var = this.peekTokenalue = this.pan, ctor);
  rseVariableDeclarationList_();
    this.checkarseClassDeclarat
    var body = this.parseFunctionB name, fun on();8mes as.pees;
    return new Block(this.geotation, initializer);
  }

  /**
   *
        return t
    return this.parseFunction2_(start, asyncToken, ctor);
  }
eIfSt_PAier_thisart, functionKind_();ClassExprebleDeclarationList_eStartLocation_();

    var = this.peekTokenalue = this.pan, ctor);
  rseVariableDeclarationList_();
    this.check
        retur
    var body = this.parseFunctionB name, fun o();9mes a this.c;
    return new Block(this.geotation, initializer);
  }

  /**
   *common first (base
    return this.parseFunction2_(start, asyncToken, ctor);
  }
   swirivate
   *ingreak;
  functionKind_();ClassExprebleDeclarationList_eStartLocation_();

    var) {
    var start = thirClass = null;
    in, ctor);
  rseVariableDeclarationList_();
    this.checkcommon first (bignmentExpression();
    this.eat_(CLOSE_SQUARE);

 onHarmony:mes ayisit(;
    return onayisit( [at_(CLOSE_ttern new Block(this.geotation, initializer);
  }

  /**
   * this result);
  }

  /**turn this.parseFunction2_(start, asyncToken, ctor);
  }
YIELDrivate
   *ingreak;
  functionKind();
is thisFstar    if (type_();ClassExprebleDeclarationList_eStartLocation_();

    varis thisFstar 
      annot this.validat) {
    var start = this.getTreeStartLocation_();
      break;
       this result);
                           initializer))ssibleImpliris thisFstentExpression();
0mes aeiths;
    return new Block(this.geotation, initializer);
  }

  /**
   * 
        return this.optseStric}
  }

  peekId_(tyhis.eitializer_(exptateme;
   acr  amayof thincludstareithsThese mig') {
    if (!this.options_.spread)
      return this.parseUnexpeptySock}
   * @private
   gIdentifier_();
) {
    var start = thirClass = null;
   }

    this.eat_(OPEN_PAier_this.eat_(CLOSE_PAREN= this.gethis.opti this.check 
        retifier_();
    }

    this.eatPossibleImpli
rt), name, fun on();11mes a result;
    return new Block(this.geotation, initializer);
  }

  /**
   *      return this.);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @privateatemeock}
   * @private
   gIdentifier_();
) {
    var start = thirClass = null;
   }

    this.eat_(OPEN_PAier_ * @private
   */
  parseBlock_IREDindings = this.parseAREDindings_();
    }

    this.eat_t_(OPEN_CURLY);
    var      return thifier_();
    }

    this.eatPossibleImpli
IREDindings     t_(CLOSE_CURLY);
    reion_() {
    return this.parseClassShared_(ClasREDindings_());
  }

  /foundpressioindinging   if (typeock_() {
    rn {Array.<ParseTree>}
   * @priva/ 12.1 Block
  /**
   * @return {Block}
   start = this.getTreeStartLocation_(} ngInitASnt_();
    T:
        if (!this.options_r_();
) {
    var start = thirClass = null;
       T:
    
  }
s_ [];);
     * @priva/ 1kType_()= this.parseAREDatement alalue = this.......is.nextTokenheckaREDindingifier_();
    }

    this.eatPossibleImpli
/ 1kType_(.peekRest_(this.peekType_())) case CLASS:
        e_() {
toundpressioindingeclaration.
     is.eitializer_(exptart = / 1kType_()mayoe if (e;
 stateme        cnding'peekRest_(thi
 this.is.pushAthhhhhfoundpressioindingingl
        } (thi
_();
    T:
        if (!this.options_r_
    
  }
s_ [];);
     * @pis.nextTokenheckpressioindingtartLocation_();
    var token =his.parseAREDatement alalue =.peekRest_(this.peekType_())))
          debugesult.push(this.par(thi
_();
ier.lhs.l s.parseL);
    reion_() {
    return this.parseClassShared_(ClasREDatement alalue = }

  /**
   * @return {
  /**
 t paements.<ParseTree>}
   * @p result.pushtTreeStartLocation_Location_(} ngInitASnt_();
     case CLASS:
        etions)
eat_t_(OP
        etionsEND_OF_Ftement_();
  esult.push(this.par(thi
_();
this.nextToken_();
     atement apeekType_());
 ll;
    in,, fun on();13mesr;
 ;
    return new Block(this.geotation, initializer);
  }

  /**
   *      return this);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @privattemenparseBlock_value = nctionKind_();ClassExprebleDeclarationList_eStartLocation_();

    varvalue = this.parserClass = null;
    in, ctor);
  rseVariableDeclarationList_();
    this.check      return ttartLocation_();
    var token vemiColon_();
  on();14 Tre);
    return new Block(this.geotation, initializer);
  }

  /**
   * r       return);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @privatTRY_PAier_this.eat_(CLOSE_PARENreturn this.paock_IRsulretur_();
      typeAnnotation = CAemeo(statement);sulretur_()=his.parseARsule = this.pan, c
  /finallyretur_();
      typeAnnotation = FINALif (constr ==finallyretur_()     case Iinallyreture = this.pan, cion2_;sulretur_(();
  = STAinallyretur_(itat_(Er lhs = this.eitializer_(ex"'_;sul' * P'Ainally' 
  parse."is.optication,
          r       ret   return new FormalParameter(th For
c;sulretur,TAinallyretur name, fun s.parseLC;sulier Initiac;sul (LC;sulifier_(); )    retur .parseLC;sulifier_(); er Initializeropt
   *   Br Initializeropation;
tur .parseLk(this.geotation, initializer);
  }

  /**
   *aRsule =  /**
   * @return {VariableStatement}
   * @private
   *c;sulretur;
    }

    thisAemeock}
   * @private
   gIdentifier_();
b   swikBindiar start = this.getTreeStartLocation_();lhs = titializerAllowed = undefineation;
    if (tthislhs = titializerAllowed = undefinePattern_();
      t}

    this.eat_(OPEN_PAier_thisc;sulreat_(CLOSE_PARENreturn this.paIRsulretur_();eckaRsul   return new FormalParameter(this.getTs.pushAthhhhhhhhhhhhhhhhhhhhc;sulreat();
    this.cc;sulretur;
   parseFunctionDeclaration_() {
    return this.parseFunction_(inallyreture =
    return this.parseFunction2_(start, asyncToken, ctor);
  }

INALif PAier_thisfinallyretur_()     case return this.pa this.checkIinally.push(this.parseFormalParameter_inallyretur name, fun on();15mes a return s;
    return new Block(this.geotation, initializer);
  }

  /**
   * return this.parseCorameter,
        typeAnnotation, this.popAnnotations_());
  }

 reak;
 _PAier_ this.parseVariableDeclarationList_();is.pa this.check return this.parsrSet);
      }
    } else {
      t_(CLOon(1.1 Primare)rClass = nsurn new Block(this.geotation, initializer);
  }

  /**
   *Primare result);
  }

  /**tart = this.getTreeStartLocation_();
  )
          retinitReq     peekType_tatedDe ?aration.
     is.e
   *ad_(ClassDeclaratio:aration.
     is.e
   *Syntaxzer_(exppecifier.lhifiervndinord'peekRest_akStateI        retinitReq     
   *  i name it is
          rseTryd.type ==       reter_()    *   Bit_();
    }

on,
  FunctionExpreeFormalParameter_());
ee = this.parseNamedExportaration.
    )    *   Bfi; i++) {
     .allowAwait = fueclaration.
  v}

  parseLiteraportSpeciNoLak;T

   _();sElements_(rameter_( parsie    return this.
  parseF.is.pushAthhhhh   vf (this.optio)    *   Bfi; i++) {
     ;s.pushAthhhhhncToken, FunctionDeclaration);n this.parseAsyncFuncti      } (thi
_();
    }      retinitReqi; i++) {
        rseTrNUMB==       reDoWhiTRING       reDoWhTRsses)
    hrowStALSses)
    hrowSNULL       retinitReq     
   *art = tname it is
          rseTrComputedPro       retinitReq     
   *ion_(art = t
          rseTrCompument_();
      case DO:
        Objierart = t
          rseTrCompu(OPEN();
      case DO:
        Primare result);
, thigetpeekotaes
          rseTrS
  H:       rseTrS
  H_ive()tch (type) {
      // Most cogulanctionExpreart = t
          rseTrNO_SUBSTITUarse_TEMPLATses)
    hrowSTEMPLATs_HEAD       retinitReq     
   * eleD;
 art = t
 at_(END       rseTryMPLEM.tySes)
    hrowSyStatement_();
  hrowSPACKAGnt_();
  hrowSPRIVATses)
    hrowSPROTECTEDes)
    hrowSPUBLIC       reDoWhiTATIC       reDoWhYIELD    var type = this.}
  }

  peekId_(ty retinitReq     
   *
on,
  FunctionExpreeFormalParamehis.eitialiRfiervndvar annotations =    if (!thiormalParameST:
      case LE      reDoWhEND_OF_Ftement_();
     case BREAK:
   yntaxzer_(exppecifier.lhendthisinpug') {
    ng)
          debugis();
  BREAK:
  */
  parseSpreadEiteraportSpeci_( ll;
    in,, fun SE_CURLY);
    ret.strew FunctionBody(this.getTreeLocation_(st.strew Functiois.);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @privateUPERthis.pa this.checkt.strew FunctiorSet);
      }
    } else {
      t_(CLOSE_CURLY);
    re  i name it isinitializer);
  }

  /**
   *  iClassDeclaration);
  
  // 12.1 Block
  /**
   * @return {Block}
   * @privatteISthis.pa this.check  iClassDeclarrSet);
      }
    } else {
      t_(CL null;
    var annotatiomalParameterList(this.getTrion,
        t_(CL  = undefinePattern_();
   /**
   * @return {VariableStatement}
   * @private
   *)    *   Bit_();
 syncFunctions  this.check
definePattern_()
    var typeAnnotation = this.pattern_()     t_(CLOSE_CURLY);
    re
on,
  FunctionExpreinitializer);
  }

  /**
   * on,
  FunctionExpreeFo  /**
   * @return {VariableStatement}
   * @private
   *)    *   Bit_();
 syncFunctions  this.check_on,
  FunctionExpres.parseBindingElementInitializ.pattern_()     t_(CLOSE_CURLYurn nalreDoWhhis
   * on,
  FunctionExprees.<P = his.ss kyword(s
   * Script or 
on,
  FunctionExpreinitializer);
  }

  /**
   * on,
  Fund CoctionExpreeFo  /**
   * @return {VariableStatement}
   * @private
   *)    *   Bit_();
 syncF
    if (this this.check_on,
  FunctionExpres.parseBindingElementInitializ.pattern_()     t_(CLOSE_CURLYcript or art = tname it isinitializer);
  }

  /**
   *art = tname it is
    /**
   * @return {VariableStatement}
   * @private
   *lrt = trn {Vari    art = tpertyName_() {
    var start = tctionExpres.parseBindingElementInitializ.lrt = t     t_(CLOSE_CURLY);
    re ertyinitializer);
  }

  /**    art = tpertyNamarameterList(this.g    if (!this.op parseFunctionDeclaration_() {
    return this.parseFunction_cogulanctionExpreart = t
    /**
   * @return {VariableStatement}
   * @private
   *lrt = trn {Vari    cogulanctionExpreart = tpertyName_() {
    var start = tctionExpres.parseBindingElementInitializ.lrt = t     t_(CLetTreat_(Dd,
                    parameters, typeAnnotation, annotatiadExpr    t_(CLOon(1.1.4 ion_(tart = t)rClass = narseFunctionon_() aon_(tlrt = tr    delegis.s    {@cr  a
   *ion_(sionrehent is
}vf nctionneeded } el.parseLion_(art = t er Initia[ Elit is ancationitia[ Elis.getTrecationitia[ Elis.getTrec, Elit is ancationitionitElis.getTrecer InitiaElit is ancs.getTreeStartLocatir InitiaElit is anc   Fs.getTreeStartLocatir InitiaElis.getTrec, Elit is ancs.getTreeStartLocatir InitiaElis.getTrec, Elit is anceat_(DO  //   ForitionitElit iscer Initia,r InitiaElit isa,r Ini_CURLYurt_(DO  //  cer Initia   Fs.getTreeStartLocatir IninctionDeclaration_() {
    return this.parseFunction_ion_(art = t
     /**
   * @return {VariableStatement}
   * @private
   *ingreak;
 rtate
   *ierClass = rn {Array * @private
   N_SQUARE);
   turns.getTreeStartLocation_();
    varrn this.
O== STStricee = thisaon_(sionrehent is 
      case e
    var typon_(sionrehent is
nitiali {Array.<ParseTree>}
   * @pre
   */
  parseClassElements_() {
    var r      .is.pushAthingreak;
  functionKind);
 this.peekType_();
eat_(Dd,
     .is.pushAthingreak;
  fu BREAK:
   art), result);
  }onKind);
 this.peekType_();
s.getTreeStartLocatid,
     .is.pushAthingreak;
  fu BREAK:
  s.getTreeStartLocation_();
 lassElement_(this.peekType_())) {
e_())) ierClasstTokenat_(CLOSE_SQU   * @pre
   */
  parseClassElements_() {
    vinitt_(OPEN_SQUARt_(this.p
    
  }
s_    l;
    in, ctor);
  eat_(OPEN_SQUARE)() {
    var stion_(art = tctionExpres.parseBindingElementInitializ.ierClass name, fun s.parseLCrseClassctionlizeaon_(tcionrehent is } el.parseLion_(sionrehent is er Initia[ sionrehent is ationitionitsionrehent is er InitiaForsionrehent isindingisionrehent isinding* tartLocatir Ininctionsionrehent isindingier InitiaForsionrehent isindingr InitiaIfsionrehent isindingr Inir InitForsionrehent isindingier Initiais.getFor    swiYhis.getTreeLoc)r Inir InitIfsionrehent isinding ier Initia) {
s.getTreeLoc)r Inir InitFor    swiYer Initializeropt
   *   Br Initializeropation;
tur .parseLkstElemegElement}n thisparseLieclaration_() {
    retFunction_ion_(sionrehent is
nitiali  /**
   * lTrec()=his.parseAionrehent ist = this.getT();
) {
    var start = this.getTreeStartLocation_();
    this.eat_(OPEN_SQUARE)() {
    var stion_(Aionrehent iss.parseBindingElementInitializer_(initiiiiiiiiiiiiiiiiiiiiiiiiiiilTre.eat_(CLOSE_SQUARE);

parseAionrehent ist = thi /**
   * M els@retureithsis.ge   )/**
   * lTrec()[=his.parseAionrehent isF);sEl]ements.<ParseTree>}
   * @pturns.getTreeStartLocation_();
     result.push(statementarseVariableStatemeniilTretToken_();
     Aionrehent isF);sElpeekRest_(this.peekType_())) casell through.
iilTretToken_();
     Aionrehent isnnot.peekRest_(this.peekType_())))
          debugesult.puslTre.par(thi
_();
}UARE);

parseAionrehent isF);sEl
    return this.parseFunction2_(start, asyncToken, ctor);
  }

ORock}
   * @private
   gIdentif**
   * lefec()=his.parseFor    swicToken, ctor);
  cFunOFtif**
   * rt = toOpt_();
    }
rationList
      t}

    this.eat_(OPEN_PAier_ this.checkaronrehent isF);s.parseBindingElementInitializ.lefe, rt = toOSQUARE);

parseAionrehent isnnot.);
  }

  // 12.1 Block
  /**
   * @return {Block}
   * @privatIFock}
   * @private
   gIdentifier_();
) {
    var start = thirClass = null;
   }

    this.eat_(OPEN_PAier_ this.checkaronrehent isIfignmentExpression();
    this.eat_(CLOSE_SQUARE);

 on(1.1.4 Objiertart = t)rClass = narseFunctionDeclaration_() {
    return this.parseFunction_Objierart = t
  ),
        typeAnnotation, this.popAnnotations_());
  }

  p{
    rn {Array * @private
   t_(OPEN_CURLexpressionIn      Assity;
        t_eStartLocation_();

    varvar p Assity;
        r start = thi  Assity;
        n_();
    is.nextTokenp Assity;
        lements_() {
!tor);
  c          t_(this.peekType_()) in, ctor);
  eat_(OPEt_(OPEN_CURLY);
    varObjierart = tctionExpres.parseBindingElementInitializ.r   this.eat_(CLOSE_CURLY  Assity;
        Yer Initia on,
  Fund Cor Initia false;
    this.allr Initia  Assity.all :cs.getTreeStartLocatir InitiaMethod;
        }
 
  /**
   *PrAssity;
        n_),
        typeAnnotation, this.popAnnotations_()
        tor) {
    var start = th();
isthisicing   if (
ts_() {
Stricee = thisation_();
    this.ee = thisp AssityMethodsYield = funcnotation = UNCTIO

    whiis();
      case Gtion_();Methodas);
    psthisic, rn l;
    i = th();
  parseLiteraportSpecins_());
  }

FunctionDeclarati  Assity.allns_()
    ) {
Stricee = thisp AssityMethodsYiecnotation = e
   gIdent 
      case e
    var tyMethodas);
    psthisic, Annotation);
 ionBodrn l;
    ) {
StrictDirect = [];OMMA)) {
 ock_value =  BREAK:
  s.getTreeStartLocation_();
 laY);
    var  Assity.alls.getTreeS
    var body = this.parseFunctionBoer_(initiiiiiiiiiiiiiiiiiiiiiiiiiii)) {
 ocmiColon_   i = th();
 .getTreeStartLocation_();
    vaionBturn this.LITERAL_PRe
 RTY_NAMEOMMA)) {
 ock_ionBLrt = trn ionBtlrt = tpertyements_() {
ionBLrt = t.allowAwaitGETortaration.
  ionIn      Assity.allns
    this.pushAthis();
      case GetAccLoc);sE);
    psthisic, rn l;
   ) {
e_())) ) {
ionBLrt = t.allowAwaitSETortaration.
  ionIn      Assity.allns
    this.pushAthis();
      case SetAccLoc);sE);
    psthisic, rn l;
   ) {
e_())) ) {
());
ee = this.parseNamedExport ionBLrt = t.allowAwait = fuortaration.
  ionIn      Assity.allns
    this.pushAth   vf (thrn ionBLrt = t;s.pushAth   vFunctionDeclarati  Assity.allns_().pushAthis();
      case Methodas);
    psthisic, f (th
 ionBodrn l;
   ) {
e_())) ) {
());
ee = thisp Assity.allShorthaowYield = func  ionBLrt = t.  parametnd.type ==={
    var n   this.}
  }

  peort ionBLrt = t.  parametYIELDr   /**
 ))) ) {
());
ion = this.pa.is.pushAthhh  parseLitera    if (!this.options_r_();
as been any added CoverIn  */
  pas been any added CoverIniPAier_ons_r_();
at_( =  BREAK:
  s.getTreeStartLocation_();
 la.
  ionIn.Yield = false;
    this.allow.at_(,nas been any added CoverInrn() && la.
  ionInas been any added CoverIni++_();
 la.
   this.checkar been any added Cos.parseBindingElementInitializer_(initiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiionBLrt = t,h  par.eat_(n_();
 la.
} /**
 ))) ) {
ionBLrt = t.  parametYIELDrld = func  ionBLrt = ts.eatId_on,
  Funif (!
ionBLrt = t.xpressio, YIELDriv).pushAthis();
  var  Assity.allShorthaows.parseBindingElementInitializer_(initiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiionBLrt = t l;
   ) {
e_())) ) {
());
}
  }

  peort ionBLrt = t.psth  }
Kyword(()Rt_(this.p
    itialiRfiervndvar annotatiionBLrt = t l;
   
 this.) {
ionBturn this.   PUTED_PRe
 RTY_NAMEOt_(this  parseLiteraportSpecins_()_CURLY);
    BREAK:
  */
  parseSpreadEiuncti    , fun s.parseLCd_(Cl  //  cer InitiashisiciMethod;
        }
 
  iaMethod;
        }
 
 }
 
  Method;
        cer Initia  Assity.all ( @return {FormalParama.iowYield;
     }r Initia*a  Assity.all ( @return {FormalParama.iowYield;
     }r InitiaeBia  Assity.all ( a.iowYield;
     }r InitiasBia  Assity.all (   AssitySetn {FormalParama.iowYield;
     }r Ini /**
   *ad_(Cl  //  
  ),
        typeAnnotation, this.popAnnotations_()
        Location_(s =  BREAK:
  sopt
    var start = this.getTreeStartLocation_();
  ();
isthisicing   if, tor) {
    var start = th result.push(statement);
  iTATIC       r@priva/ 1kihis.options_.a    if (!this.options_s.getTreeStartLocation_();
       result.push(statementar  rseTrCompu(OPEN();
       r@privaart, fun start = t  Assity.alls);
    / 1kihis.opn_();
 la.
    case e
    var tyMethodas);
    psthisic, Annotation);
 ionBoer_(initiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiLocation_(srn() && la.
  )
          debuges 
isthisicingl
        } (this.) {
    var reNCT    this.ee = thisation_();
)er_(initiiiiiiiis();
      case Gtion_();Methodas);
    l
  ,iLocation_(srn() && la.
  iiis();
      case ad_(Cl  //  2as);
    psthisic, focation_(srn(la.
  ii}      reteekTypeatement);
  iTA (!this.options_.bl    case Gtion_();Methodas);
    psthisic, Location_(srn() && la)
          debugis();
  BREAK:
  ad_(Cl  //  2as);
    psthisic, focation_(srn(la.
}UARE);

parseGtion_();Methodas);
    psthisic, Location_(sr);
  }

  /for) {
    var  * @privatethis.valid   vFunctionDeclarati  Assity.allns_().puscase e
    var tyMethodas);
    psthisic, Annotation);
 ionBodfocation_(srn(laE);

parseMethodas);
    psthisic, Annotation);
 ionBodfocation_(srssionIn
   * @rete
   gIdentifier_();
p {FormalParam()=his.parseForturn {Formals_();
    }

    this.eat_gIdentifier_();
etTreeStartLocation_();
    var binding = this.parseBindi.eat_(CLOSE_PARENart), id, typeAnnotation);
  }

 rmalParaEN_CURLY);
    varP AssityMethods.getTreeS
    var body = this.parseFunc/**
 ))) )sthisic, Annotation);
 ionBod }

 rmalPararseTypeAnnotatioc/**
 ))) focation_(si
rt), name, funarati  Assityires an initializeras);
    psthisic, ionBodfocation_(srssionIn();
etTreeStartLocation_();
    var binding = this.parseB * @privatesult = [];);
    this.check  Assityires an initializer
    var body = this.parseFunc/**
 ))) )sthisic, ionBod');

    return focation_(srn(laE);

parsead_(Cl  //  2as);
    psthisic, focation_(sr);
  }

  /for) {
    var start = th();
FunctionDeclarati  Assity.allns_().pus this.getTreeStartLocation_()).pus oneODO(arv): Can we unifyreeStreiths
   *PrAssity;
        ? this.) {
ionBturn this.LITERAL_PRe
 RTY_NAMEYield = funcionBtlrt = tperty.allowAwaitGETortaration.
ionIn      Assity.allns
    this.pushAis();
      case GetAccLoc);sE);
    psthisic, focation_(srn(la.
}Uthis.) {
ionBturn this.LITERAL_PRe
 RTY_NAMEYield = funcionBtlrt = tperty.allowAwaitSETortaration.
ionIn      Assity.allns
    this.pushAis();
      case SetAccLoc);sE);
    psthisic, focation_(srn(la.
}Uthis.) {
());
ee = this.parseNamedExportld = funcionBturn this.LITERAL_PRe
 RTY_NAMEYield = funcionBtlrt = tperty.allowAwait = fuortaration.
ionIn      Assity.allns
    this.pushA   vf (thrn ionBtlrt = tpertyements_(   vFunctionDeclarati  Assity.allns_().pushAis();
      case Methodas);
    psthisic, f (th
 ionBodfocation_(srn(la.
}Uthis.) {
 this.peekType_memberVres an riken.rn this.e
   gIdenthis.pushAis();
      case Methodas);
    psthisic, Annotation);
 ionBodfocation_(srn(la
      break;
  nDeclarati  Assityires an initializeras);
    psthisic, ionBodfocation_(srn(laE);

parseGetAccLoc);sE);
    psthisic, focation_(sr);
  }

  /for) {
    var start = th();
FunctionDeclarati  Assity.allns_().pus
   * @rete
   gIdentifier_}

    this.eat_gIdentifier_();
etTreeStartLocation_();
    var binding = this.parseBindi.eat_(CLOSE_PARENart), id, typeAnnotation);
 at_(END_Os. this.checkGetAccLoc);s.parseBindingElementInitializ.psthisic, ionBoer_(initiiiiiiiiiiiiiiiiiiii');

    return focation_(si
rt), name, funaratiSetAccLoc);sE);
    psthisic, focation_(sr);
  }

  /for) {
    var start = th();
FunctionDeclarati  Assity.allns_().pus
   * @rete
   gIdentifier_();
p {FormalParam()=his.parse  AssitySetn {FormalPara_();
    }

    this.eat_gIdentifier_();
.eat_(CLOSE_PARENart), id, typeAnnotation);
  }

 rmalParaEN_CURLY);
    varSetAccLoc);s.parseBindingElementInitializ.psthisic, ionBoer_(initiiiiiiiiiiiiiiiiiiii }

 rmalPararsfocation_(si
rt), name, funOSE_CURLY);
    rents ea)eter(this.getTreeLocationals  Assity;
        t_emalParameterList(this.getTr  Assity.allns
    ={
    var n  paramieNCT    this.ee = thisp AssityMethodsYiecnotatee = thisation_();
name, funOSE_CURLY);
    rents ea)eter(this.getTreeLocationals  Assity.allns
    ={ = th result.push(statement);
  yd.type ==       reDoWhiTRING       reDoWhNUMB==       rptions_.bl
        } ngIniComputedPro       retinitReq     peekType_tomputed  Assity.allnements_()
          debugis();
  BREAKon 
      reisKyword(()n(la.
}UARE);

OSE_CURLY);
    rents ea)eter(this.getTreeLocationals   break;
      cas     rssionIn();
e parseLiteraportSpecins_());
 is();
    return this.nd.type === STSerty.allowAwaits     s.eat_(CLOSE_CURLY  AssitySetn {FormalParamer Initializeropt
   *   Br Initializeropation;
tur . /**
   *PrAssitySetn {FormalPara_()),
        typeAnnotation, this.popAnnotations_()
        b   swikBindiiterapushsopt
    var start =ar start = this.getTreeStartLocation_();lhs = titializerAllowed = undefineation;
    if (tthislhs = titializerAllowed = undefinePattern_();
   fier_();
etTreeStartLocation_();
    var binding = this.parseBindi }

 rmal fun stForturn {Formal
    var body = this.parseFunc/**
 ))) heck
definel  //     return new FormalParameter(this.getT at_(Enitializer');

    return on_();opsopt
    var s));is.pa this.check@return {FormalPara( }

 rmal.xpressio, [ }

 rmal]is.op parseFunctionDeclaration_() {
    return this.parseFunction_Primare result);
, thigetpeekotaes
  ),
        typeAnnotation, this.popAnnotations_()
    
   * @rete
   gIdentifart =ar start = th}

ORoYiecnotatee = thisation_();sionrehent is 
      case e
    var tyGtion_();sionrehent is
nitiali {Arrayis();
  BREAK:
  ar be@returs
nitiali {me, funaratiSyntaxzer_(exllnsage ),
        typeAnnotation, this.popAnnotations_()    
   *itializer_(exllnsage ifier_();
es.options_.a    if (!this.optiY);
    varSyntaxzer_(thistartLocation_();
    var token = par.ellnsage ifiearation(this.getTreeLo*}
Funct.all of temeSerty. is.optobjiertaowYIdentifie
rtthr Initia ts     igy    a usal friendlyts     
   * Script or Syntaxzer_(this}r Ini /**
   **/
  parseSpreadEionB arameterList(this.geratiSyntaxzer_(ex`pecifier.lhes.opt${ionB}`SQUARE);

 on(1.14)rClass = nsu;

OSE_CURLY);
    rents ea)eter(this.getTreeLocationalstartLocatid,
    ={ = th result.push(statement);
  NO_SUBSTITUarse_TEMPLATses)
    hrowSTEMPLATs_HEAD       retinitReq     ee = thisteleD;
 art = ts      } ngIniBANG       reDoWh)
          r case CLETses)
    hrowStALSses)
    hrowS
  parsees)
    hrowSyd.type ==       reDoWhMINUS       reDoWhMINUS_MINUS       reDoWhNEWes)
    hrowSNULL       rrseTrNUMB==       reDoWhCompument_();
    rseTrCompu(OPEN();
    ngIniComputedPro       rhrowSPLUS       reDoWhPLUS_PLUS       reDoWhS
  H:
 onrogulan
) {
    varlrt = t      reDoWhS
  H_ive()tch (typeDoWhiTRING       reDoWheUPERes)
    hrowSTeI        rhrowSTILDses)
    hrowSTRsses)
    hrowSTYPEOFes)
    hrowSVOIDes)
    hrowSYIELD    var tyions_.bl
        } )
          debugis();
    if (types.op, fun SE_CURLY.getTreeLocer Initias.getTreeStartLocatir InitiaEgetTreeLoc,Fs.getTreeStartLocatir IninctiontartLocatiNoIocer Initias.getTreeStartLocatiNoIor InitiaEgetTreeLoNoIoc,Fs.getTreeStartLocatiNoIor IninctionDeclaration_() {
    rettion
  // por.  Bindingreak;
   tiorationList}IN{
      ();
as been any added CoverIn  */
  pas been any added CoverIniPAier_();
) {
    var start = thirClass = nnotatation;
  ingreak;
   );
    }

   Yield = false;
    this.allow.at_(leImpli
Is been any added CoverInrn(ebugis();
 ingreak;
 rtat, funaratirClass = nnotatation;
  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *ingreak;
  =  BREAK:
  s.getTreeStartLocatioingreak;
   );
    peAnnotation = C      his.pushA   vingreak;
 s = rat_(CLOSE_tternnnnnexpressionIn
  c          .is.pushAthingreak;
 stToken_();
     s.getTreeStartLocatioingreak;
   ) l;
   ) {
 debugis();
 heckaromactionExpres.parseBindingElementInitializ.ingreak;
 srn(la
      break;
  ingreak;
 rtat, fun on(1.13Fs.getTreeS.ingreak;
 su;

OSE_CURLY);
    rents ea)eter(this.getTreeLocationalss.getTreeStartLocatid,
    arameterList(this.getTrtartLocatid,
    ifiearation(this.gs.getTreeStartLocaticer InitiaC
  Comma tctionExprer Initia this result);
r Initiaser_wart), idr Initias.yncser_wart), idr InitiaLeftHandSi; rClass = n = s.getTreeStartLocatir InitiaLeftHandSi; rClass = n s.getTreeSOp = toOps.getTreeStartLocatir Ininctions.getTreeStartLocatiNoIocer InitiaC
  Comma tctionExpreNoIor Initia this result);
r Initiaser_wart), idr Initias.yncser_wart), idr InitiaLeftHandSi; rClass = n = s.getTreeStartLocatiNoIor InitiaLeftHandSi; rClass = n s.getTreeSOp = toOps.getTreeStartLocatiNoIor IninctionDtTreeLotartLocati=} ingreak;
   nctionDeclaration_() {
    rettion
  //s.getTreeStartLocatioingreak;
   tiorationList}NORMALn this.optseStrichis.s thisYiecnotation = YIELDr 
      case e
    var ty this result);
  } {
    if (!this.options_.spread)
      return th
    if (vy ads.yncotaesing   if (
ts_() {
Stricee = this.parseNamedExport his.getTr   break;
      ca = fuethis.pushA   vf (thT parseLiteraportSpecins_());
 hA   vmaybeOp notaesT parseLiteraportSpecins1_());
 hA   ads.yncotaesingmaybeOp notaesT par..rn this.e
   gIdenYield = func  f (thT par.xpressio  Yd.lak;thisld = func      maybeOp notaesT par.xpressio !this.lak;lon_   i = th();
lefec()=his.parseC
  Comma t  ingreak;
   );
     this.getTreeStartLocation_()).pus) {
Stricee = this.parseNamedExport lefeturn this.nd.type ==_EXPRESSrseYield = funclefeti; i++) {
     .allowAwait = fuYie   params.nd.type ==;

    varieAnnotation SpeciNoLak;T

   _();sElvinitat_(Er lhs = t      b   swiI    *   Bit_();
    }
ndefinePattern_();
      tushA   vf (thT parseLlefetI; i++) {
     ;s.pushAthcase e
    var typon_wart), idsE);
    b   swiI    *   Boer_(initiiiiiAsyncFuncti      } 
 ());
 this.) {
    var rARmenp

    varieAnlefeturn this.COV==_FORMALSikenlefeturn this.nd.type ==_EXPRESSrsets.pushAthis();
      case pon_wart), idsE);
    lefe, at_(END       ieAn   ads.yncotaesirt lefeturn this.CALL_EXPRESSrsethis.pushAth   vfon_wT parseLiteraportSpeciNoLak;T

   _();sElements_(raieAnfon_wT parsinitat_(Er lhs = t  hA   vf (thT parseLlefetAssiandfi; i++) {
     ;s.pushAthhhis();
      case pon_wart), idsE);
    lefe.args,iAsyncFuncti      } )) {
     specifie
funclefe  */
  pas be@retursTootaes result);
  lefetifart =ar start = ths.getTreeSOp = toOns
    this.pushA) {
    var rthis.pld = funclefe  */
  ptrans_())LeftHandSi; rClass = ns.lefetifart =s.) {
 lefetisLeftHandSi; rClass = nulYie  lefetisation;
n_Location_(} 
   *itializer_(ex'Left haowYsi;  of a.getTreeS.  elsbe hecr
c;ll.ellmber, Annotati, primare)ingreak;
 s oOpdesl
 c();lizeption;
'i      } 
 ));
 hA   vop = toOpions_.a    if (!this.option }

 ight =  BREAK:
  s.getTreeStartLocatioingreak;
   );

 debugis();
 heckndeare result);
s.parseBindingElementInitializ.lefe, op = toO,
 ightrn(la
      break;
  lefeifiearation(this.gTrans_())s aaLeftHandSi; rClass = n in   a s.getTreeSation;
.) {pseVaria
   * STeStreak;
 s temeSrans_()).lhedin.) {itn
  //s as (lvs.getTreeSation;
,r Initoaramwiis.ptreak;
 s temeo iginalhedin.nitializtElemeotation, i edinnctionDeclaration_() {
    rettiontrans_())LeftHandSi; rClass = ns.edin ={ = th result.pdin.push(statement);
  ARmAY_LITERAL_EXPRESSrse();
    ngIniCBJECT_LITERAL_EXPRESSrse();
    } 
   *scann();.   exingl
in.xpressio !this.offset      } )) onIf we fail    pn_() as (lvs.getTreeSation;
 temn     } )) onK:
  s.getTreeSation;
  wi    ake ngr a tialilizeeer_(s
   *Athhhis();
      case p.getTreeSation;
  = this.pan, cions_.bl
ereeStt_(CLOSE_CURLY);
    rents ea)eter(this.getTreeLocationalss.getTreeSOp = toOns
    arameterList(tiss.getTreeSOp = toO,
    ifiearatioon(1.12aC
  Comma t)rClass = narseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *ars Comma t  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *c
  Commar start = thiLogic;lOR  ingreak;
   );
    ) {
StrictDirectQUESarseF(statement)
  Commar start toPrimare result);
  )
  Commais.option }

lefec()=his.parses.getTreeStartLocation_();
 la}

    this_ [];);
      }

 ight =  BREAK:
  s.getTreeStartLocatioingreak;
   );
 debugis();
 heckC
  Comma tctionExpres.parseBindingElementInitializer_(initiiic
  Comma,
lefe,  ightrn(la
   ebugis();
 c
  Commaifiearatihecndeare result);
sE);
    lefe, op = toO,
 ightrstatemelefe  */
  ptoPrimare result);
  lefetifebugiight =  BREAtoPrimare result);
   ightrn(la
 is();
 heckndeare result);
s.parseBindingElementInitializ.lefe, op = toO,
 ightrn(laaratioon(1.11 Logic;l ORarseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *Logic;lOR  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseLogic;lAND  ingreak;
   );
     thiop = toO;
    expressop = toOpions_.a  t thisORethis.pushA   v ight =  BREAK:
  Logic;lAND  ingreak;
   );
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioon(1.11 Logic;l ANDarseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *Logic;lAND  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseBitwiisOR  ingreak;
   );
     thiop = toO;
    expressop = toOpions_.a  t thisANDethis.pushA   v ight =  BREAK:
  BitwiisOR  ingreak;
   );
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioon(1.10 Bitwiis ORarseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *BitwiisOR  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseBitwiisXOR  ingreak;
   );
     thiop = toO;
    expressop = toOpions_.a  t thisBARethis.pushA   v ight =  BREAK:
  BitwiisXOR  ingreak;
   );
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioon(1.10 Bitwiis XORarseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *BitwiisXOR  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseBitwiisAND  ingreak;
   );
     thiop = toO;
    expressop = toOpions_.a  t thisCARETethis.pushA   v ight =  BREAK:
  BitwiisAND  ingreak;
   );
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioon(1.10 Bitwiis ANDarseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *BitwiisAND  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseEquality  ingreak;
   );
     thiop = toO;
    expressop = toOpions_.a  t thisAMPERSANDethis.pushA   v ight =  BREAK:
  Equality  ingreak;
   );
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioon(1.9 Equality)rClass = narseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *Equality  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseRelaomma t  ingreak;
   );
    expressionIn    EqualityOp = toOns
StartLocation_();his.pushA   vop = toOpions_.a    if (!this.option }

 ight =  BREAK:
  Relaomma t  ingreak;
   );
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioSE_CURLY);
    rents ea)eter(this.getTreeLocationalstqualityOp = toOns
    ={ = th result.push(statement);
  this._ive()tch (typeDoWhNOT_ive()tch (typeDoWhthis._ive()_ive()tch (typeDoWhNOT_ive()_ive()tch (type) {
     
          ebugis();
    if (tyaratioon(1.8 Relaomma tarseFunctionDtTreeLotartLocati} ingreak;
   nctionDeclaration_() {
    retlizer);
  }

  /**
   *Relaomma t  ingreak;
   )  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseShifStartLocatid,);
    expressionIn    Relaomma tOp = toOnsingreak;
   ) his.pushA   vop = toOpions_.a    if (!this.option }

 ight =  BREAK:
  ShifStartLocatid,);
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioSE_CURLY)tTreeLotartLocati} ingreak;
   nctionDeclaratints ea)eter(this.getTreeLocationalsRelaomma tOp = toOnsingreak;
   )

  /**tart = this.getTreeStartLocation_();
  e
   ANGLses)
    hrowSs.eat_ANGLses)
    hrowSGREAT==_Eve()tch (typeDoWhLESS_Eve()tch (typeDoWhINSTANCEOFes)
    ptions_.bl
        } ngIniIN();
      case DOingreak;
   tiiorationList}NORMAL      } )
          debugis();
    if (types.op, fun on(1.7 ShifS)rClass = narseFunctionDeclaration_() {
    return this.parseFunction_ShifStartLocatid,)  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseAd ComvetartLocatid,);
    expressionIn    ShifSOp = toOns
StartLocation_();his.pushA   vop = toOpions_.a    if (!this.option }

 ight =  BREAK:
  Ad ComvetartLocatid,);
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioSE_CURLY);
    rents ea)eter(this.getTreeLocationalsShifSOp = toOns
    ={ = th result.push(statement);
  LEFT_SHIFTtch (typeDoWhRIGHT_SHIFTtch (typeDoWhUNSIGNED_RIGHT_SHIFTtch (typtyions_.bl
        } )
          debugis();
    if (types.op, fun on(1.6 Ad Comve)rClass = narseFunctionDeclaration_() {
    return this.parseFunction_Ad ComvetartLocatid,)  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseM   ieDecaomvetartLocatid,);
    expressionIn    Ad ComveOp = toOns
StartLocation_();his.pushA   vop = toOpions_.a    if (!this.option }

 ight =  BREAK:
  M   ieDecaomvetartLocatid,);
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioSE_CURLY);
    rents ea)eter(this.getTreeLocationalsAd ComveOp = toOns
    ={ = th result.push(statement);
  PLUS       reDoWhMINUS       rtyions_.bl
        } )
          debugis();
    if (types.op, fun on(1.5 M   ieDecaomve)rClass = narseFunctionDeclaration_() {
    return this.parseFunction_M   ieDecaomvetartLocatid,)  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseExpon i++   * tartLocatid,);
    expressionIn    M   ieDecaomveOp = toOns
StartLocation_();his.pushA   vop = toOpions_.a    if (!this.option }

 ight =  BREAK:
  Expon i++   * tartLocatid,);
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatiK:
  Expon i++   * tartLocatid,)  /**
   * @return {VariableStatement}
   * @private
   *lefec()=his.parseUeare result);
sE);
    expressionIn    Expon i++   * tartLocatid,
StartLocation_();his.pushA   vop = toOpions_.a    if (!this.option }

 ight =  BREAK:
  Expon i++   * tartLocatid,);
    melefe  */
  phecndeare result);
sE);
    lefe, op = toO,
 ightrn(la
   ebugis();
 lefeifiearatioSE_CURLY);
    rents ea)eter(this.getTreeLocationalsM   ieDecaomveOp = toOns
    ={ = th result.push(statement);
  iTA (!this.orseTrS
  H:       rseTrPERCENTtch (typtyions_.bl
        } )
          debugis();
    if (types.op, fun    Expon i++   * tartLocatid,
                    parametiTA _iTA  (tyaratioon(1.4 Ueare Op = toOarseFunctionDeclaration_() {
    return this.parseFunction_Ueare result);
sE)),
        typeAnnotation, this.popAnnotations_()
    ptseStrichis.sAwaitort his.getTr   break;
      ca WAITethis.pushAStrictDirdd,);
    meoonno heclak;?.option }

Assiandc()=his.parseUeare result);
sE);
     
Assiandc()=his.toPrimare result);
  Assiand);
 debugis();
 heckAwait result);
s.parseBindingElementInitializ.Assiand);
 deb}Uthis.) {
());
etTrUeareOp = toOns
StartLocation_();his.pushA   vop = toOpions_.a    if (!this.option }

Assiandc()=his.parseUeare result);
sE);
     
Assiandc()=his.toPrimare result);
  Assiand);
 debugis();
 heckUeare result);
s.parseBindingElementInitializ.op = toO,
Assiand);
 deb}U            his.parsePostfix result);
sE);
  aratioSE_CURLY);
    rents ea)eter(this.getTreeLocationalsUeareOp = toOns
    ={ = th result.push(statement);
   CLETses)
    hrowSVOIDes)
    hrowSTYPEOFes)
    hrowSPLUS_PLUS       reDoWhMINUS_MINUS       reDoWhPLUS       reDoWhMINUS       rhrowSTILDses)
    hrowSBANG       rtyions_.bl
        } )
          debugis();
    if (types.op, fun on(1.3 Postfix)rClass = narseFunctionDeclaration_() {
    return this.parseFunction_Postfix result);
sE)  /**
   * @return {VariableStatement}
   * @private
   *Assiandc()=his.parseLeftHandSi; rClass = ns.);
    expressionIn    PostfixOp = toOns
StartLocation_();his.pushAAssiandc()=his.toPrimare result);
  Assiand);
 debug   vop = toOpions_.a    if (!this.optionAssiandc()heck ostfix result);
s.parseBindingElementInitializ.Assiandz.op = toO);
 deb}U           Assiand;
  aratioSE_CURLY);
    rents ea)eter(this.getTreeLocationalsPostfixOp = toOns
    ={ = th result.push(statement);
  PLUS_PLUS       reDoWhMINUS_MINUS       rIn();
e parseLiteraportSpeciNoLak;T

   _();sElements_(rais();
    resinitat_(        ebugis();
    if (tyaratioon(1.2 Left haowYsi;  eClass = narse/atioonAlso inlak;s temec;ll*ingreak;
  produmedExpratioSE_CURLYLeftHandSi; rClass = n er InitiaNew result);
r InitiaC;ll result);
r IninctionDeclaration_() {
    return this.parseFunction_LeftHandSi; rClass = ns.)  /**
   * @return {VariableStatement}
   * @private
   *Assiandc()=his.parseNew result);
on_()).pus on=his test is equthileeS.to is llmber eClass = narss.) {
  Assiand in@renceofaNew result);
 ={
*Assiand.argssintat_(Er l
    meoonTemeC;ll*ingreak;
  produmedExpr    meloop:s.<ParseTree>}
   * @p**tart = this.getTreeStartLocation_(   reDoWhCompu(OPEN();
       r@pAssiandc()=his.toPrimare result);
  Assiand);
 debug   r@pAssiandc()=his.
   *a;ll result);
sE);
    Assiand);
 debug   r@peekTypeatement   reDoWhComputedPro       ret r@pAssiandc()=his.toPrimare result);
  Assiand);
 debug   r@pAssiandc()=his.
   *MlmberLookup result);
sE);
    Assiand);
 debug   r@peekTypeatement   reDoWhPERIOD       ret r@pAssiandc()=his.toPrimare result);
  Assiand);
 debug   r@pAssiandc()=his.
   *Mlmber result);
sE);
    Assiand);
 debug   r@peekTypeatement   reDoWhNO_SUBSTITUarse_TEMPLATses)
       reDoWhTEMPLATs_HEAD       rettttt) {
 this.peekType_teleD;
 art = ts)er_(initiiiiiiieekTyeloop;
 debug   r@pAssiandc()=his.toPrimare result);
  Assiand);
 debug   r@pAssiandc()=his.
   * eleD;
 art = t
 Assiand);
 debug   r@peekTypeatement   r)
          debuges 
eekTyeloop;
 debug   {
     specifieecif       Assiand;
  aratioon(1.2 MlmberaEgetTreeLoceithout temeheckprodumedExarseFunctionDeclaration_() {
    return this.parseFunction_Mlmber result);
NoNews.)  /**
   * @return {VariableStatement}
   * @private
   *Assiand;this.) {
());
etTreeStartthis.
  parse;his.pushAAssiandc()=his.PARENart), idrClass = ns.);
    ssElement_(thisAssiandc()=his.PARENPrimare result);
  );
 deb}Uthis.loop:s.<ParseTree>}
   * @ptart = this.getTreeStartLocation_(  eDoWhComputedPro       ret rAssiandc()=his.toPrimare result);
  Assiand);
 debug   rAssiandc()=his.
   *MlmberLookup result);
sE);
    Assiand);
 debug   reekTypeatement  eDoWhPERIOD       ret rAssiandc()=his.toPrimare result);
  Assiand);
 debug   rAssiandc()=his.
   *Mlmber result);
sE);
    Assiand);
 debug   reekTypeatement  eDoWhNO_SUBSTITUarse_TEMPLATses)
      eDoWhTEMPLATs_HEAD       rettt) {
 this.peekType_teleD;
 art = ts)er_(initiiiiieekTyeloop;
 debug   rAssiandc()=his.toPrimare result);
  Assiand);
 debug   rAssiandc()=his.
   * eleD;
 art = t
 Assiand);
 debug   reekTypeatement  )
          debugeseekTyeloop;tiooneekTyeout ofaloop
   *Athspecifieecif       Assiand;
  arati
   *Mlmber result);
sE);
    Assiand)ssionIn
   *    if (!this.opti();
FunctionDeclsyncF
    if (this this.checkMlmber result);
s.parseBindingElementInitializ.Assiandz.ionB ;
  arati
   *MlmberLookup result);
sE);
    Assiand)ssionIn
   *    if (!this.opti();
llmber  start = thirClass = non_();
    this.eat_(OPEN_SQUARE)() {
    var stMlmberLookup result);
s.parseBindingElementInitializ.Assiandzer_(initiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiillmber ;
  arati
   *a;ll result);
sE);
    Assiand)  /**
   * argss=  BREAK:
  ArguClass if (this this.checka;ll result);
s.parseBindingElementInitializ.Assiandz.argsrn(laaratioon(1.2aNew)rClass = narseFunctionDeclaration_() {
    return this.parseFunction_New result);
on_  /**
   * Assiand;this.tart = this.getTreeStartLocation_();
  NEWes)
    
   * @return {VariableStatement}
   * @private
);
    this.eaNEWlements_(raieAnhis.getTr_(eUPER))er_(initiiiAssiandc()=his.
   *Super result);
sElements_(rathislhs = ttiiiAssiandc()=his.toPrimare result);
  =his.parseNew result);
on_      tushA   vfrgss= nctionKind);raieAnhis.getTr_(e
   gIdent ocation_(   rargss=  BREAK:
  ArguClass if (thisssss}      ret this.checkNew result);
s.parseBindingElementInitializ.Assiandz.argsrn(ation_();
  eUPERes)
    iiAssiandc()=his.
   *Super result);
sElements_(ra this.getTreeStartLocation_();
  his.tart = thush(statementar  rseTrComputedPro       ret r@pis();
      case MemberLookup result);
sE);
    Assiand);
 debug   reDoWhPERIOD       ret r@pis();
      case Member result);
sE);
    Assiand);
 debug   reDoWhCompu(OPEN();
       r@pis();
  BREAK:
  a;ll result);
sE);
    Assiand);
 debug   r)
          debuges 
Y);
    BREAK:
  */
  parseSpreadEi    ifieisssss}      reteekTypeatement)
          debugis();
  BREAK:
  Mlmber result);
NoNews.) (types.op, fun FunctionDeclaratiArguClasPara   return this.parseFunction_ioguClass if /**
   * ArguClasPara er In  * ias.getTreeSOr art), result);
r In  * iasrguClasPara ,as.getTreeSOr art), result);
r In  ***
   * A.getTreeSOr art), result);
 er In  * ia   Fs.getTreeStartLocatir In  * ias.getTreeStartLocatir/**
   * @return {VariableStatement}
   * @private
   *argss= rn {Array * @private
   gIdentifart =ar s!his.getTr_(s.eat_gIdent(statementargstToken_();
     srguClasr s));is.pannexpressionIn
  c          .is.pushAthargstToken_();
     srguClasr s));isssss}     }{Array * @privats.eat_(OPEN_PAier_ this.checksrguClasParas.parseBindingElementInitializ.argsrn(laarati     srguClasr s this.optseStric();
eat_(Dd,
StartLocation_();
 debugis();
  BREAK:
   art), result);
  }onKindis();
      case p.getTreeSrClass = non_();t_(CLOSE_CURLY   //s aon_w AnnotatistaowYptaesiingreak;
 s as well as delegis.s to_CURLY{@code
parseGtion_();sionrehent is
}opts=his begi s a ation_();_CURLYcionrehent is } el.parseLion_w Annotati supiali, seeer Inithttp://wiki.ecmascript.org/doku.php?id=strawman:aon_w_Annotati_syntax} el.parseLGtion_();Ycionrehent iss syntax is i
 tem ES6 draft,r Init(1.1.7LGtion_();Ysionrehent iss} el.parseLion_wart), idcer Initiason_wP {Formals =>kC
 cise, ty} el.parseLion_wP {Formals er Initializeropt
   *  Br Initia falsotaestemsadderClass = nAndion_wP {FormalPara} el.parseL falsotaestemsadderClass = nAndion_wP {FormalPara er Initia
s.getTreeLoc)r Initia
s)r Initia
s   FI    *   Bi)r Initia
s.getTreeLoc,s   FI    *   Bi)r IniparseL f cise, ty er Initia[lookaht), not {] s.getTreeStartLocatir InitiaiowYield;
     }r Inir IniparseLDtTreeLotartLocati=} ingreak;
   nctionDeclaration_() {
    return this.parseFunction_ion_wart), idsE);
    l
er,iAsyncFuncti);
  }

  /freturs;this.tart = thdin.push(statement);
  nd.type ==_EXPRESSrse();
    } 
din.= heck
defineI    *   B(l
in.xpressio  l
erfi; i++) {
      ifieisssss * F;ll*through.atement);
  BINDING_yd.type ==       r /freturs fun stForturn {FormalParas.parseBindingElementInitializ    debuges 
[n stForturn {Formal
 
in.xpressio er_(initiiiiiiiiiheck
definel  //    
in.xpressio  l
erT at_(En at_(odrn ] ifieissssss.peekType_()seVariabMAL_PARAMET==_LIST       r /freturs ful
ereeStissssss.peekType_())
          debugfreturs fulhis.toForturn {Formals_();
    l
er,iAsyncFuncti;
 deb}Uthis. * @privatARmenpivate
   *.eat_(CLOSE_PAREN f cise, ty_(AsyncFuncti;
 deb this.checksrn_wart), id result);
s.parseBindingElementInitializs.pushAthasyncFunct,gfretursi
rt), name, funaratiar be@returs
nitiali /**
   *  falsotaestemsadderClass = nAndion_wP {FormalPara er In  * ia
s.getTreeLoc)r In  * ia
)r In  * ia
s   F
defineI    *   B)r In  * ia
.getTreeLo,s   F
defineI    *   B)r In  *r In  * iaTemelt),lizee
   gIdenYhas (lrt),y bee
 c
 suCld.r/**
   * ingreak;
 s = rn {**
 ar s!his.getTr_(s.eat_gIdent(statementdohis.pushAth   vs.getTreeStartLocation_();
  his.ptseStric();
Rera_(
    this.pushAththingreak;
 stToken_();
     ReraP {Formalon_      tushAsss.peekType_()  ssElement_(thisththingreak;
 stToken_();
     p.getTreeSrClass = non ifieisssss} );
  his.ptseStric
  c          t_(this.piic
 tinue);is.pann}nexpress!his.getTr_(s.eat_gIdentYie  his.gisAtEn(()Rt_(th}{Array * @privats.eat_(OPEN_PAier_ this.checkar be@returss.parseBindingElementInitializ.ingreak;
 srn(la}{Arr Yield = false;
    this.allow.l
er,iIs been any added CoverInr this.optseas been any added CoverIn  = */
  pas been any added CoverIni;
 debugis();
()
        t   el fun stV  adis.Objierart = tn_();
  t   el.visitAny.edin  {**
 ar st   el.ferId;his.pushA   ve parseLt   el.eer_(     ;s.pushA/
  pitializer_(ext par.xpressio, `pecifier.lhes.opt${es.op}`SQUARpes.op, fun FunctionWhen we hav  eChausr.lheemecs be g{Fomndi seVaril anesn on_( methodnction be*   s temeremainlizeg{Fomndi   produme a primare)ingreak;
 .parseFunctoPrimare result);
  =din ={ = thptseSdin.pushthis.COV==_FORMALS;
 debugis();
  BREAas be@retursTootaes result);
  edin  {**
 ions_.bl
ereeStt_(CLv  adis.ar be@retursAsotaes result);
  edin ={ = thfreAn  r iseL0; is< l
erfingreak;
 stlength; i++this.pushA) {
 
erfingreak;
 s[i].pushthis.REST_PARAMET==this.pushAth   ve parseLn stif (!
DOT_DOT_DOT, l
erfingreak;
 s[i].xpressiorivate
);
    thitializer_(ext par.xpressio, `pecifier.lhes.opt${es.op}`SQUARpeebugis();
()isssss} ARpes.op, funas be@retursTootaes result);
  edin ={ = thptseSdin.pushthis.COV==_FORMALS;his.pushA   vingreak;
 s = l
erfingreak;
 s;s.pushA) {
ingreak;
 stlengththis.0this.pushAth   vllnsage = 'pecifier.lhes.opt)'ivate
);
    thitializer_(ext
in.xpressio  llnsage ifier_  ssElement_(thisth   thv  adis.ar be@retursAsotaes result);
  edin peatement     vingreak;
 ();
  his.ptseingreak;
 stlengtht> 1 t_(this.piiingreak;
  = heckaromactionExpresingreak;
 s[0].xpressio  ingreak;
 srn(lais.piiihislhs = ttiiiingreak;
  = ingreak;
 s[0]iv).pushAthis();
  var taes result);
xt
in.xpressio  ingreak;
 ));isssss}     }{Arrayions_.bl
ereeStt_(CLtoForturn {Formals_();
    l
er,iAsyncFunctissionIn
   *scann();.   exing!this.offset      is();
      case pon_waorturn {Formals_(AsyncFuncti;
 daration(this.gson_waorturn {Formals[ this,LGtion_();n {Formal] er Initia
sth  }
aorturn {Formals[? this,L?Gtion_();n {Formal] )parseFunction_ion_waorturn {Formals_(AsyncFuncti={ = thptseAsyncFunctis.pushA/
  privatnd.type ==;_();
    this.eae
   gIdentifier_();
p {Formalss=  BREAK:
  Forturn {Formals_();
    }

    this.eat_gIdentifier_is();
 p {Formals;
 daration(nDeclaras {Identifie}ocationalsAon_w_,
                    parametARmenYiecnotatee = thisarn_wart), id
name, funOSE_CURLY f cise, ty er Initia[lookaht), not {] s.getTreeStartLocatir InitiaiowYield;
     }r Inir IniLDtTreeLoIdent}iAsyncFunctnctionDeclaration_() {
    ret /**
   *arscise, ty_(AsyncFuncti /**
   * Teme.eat_cansbe a bxprk oOpasiingreak;
 . A '{' is always l
ear.lhas**
   * temebegi nlizeof a bxprk. = thptseSis.getTr_(e
   ment_);
 debugis();
  BREAK:
  art), id, typeAsyncFuncti;
fier_();
his.sAwaito=  BREAhis.sAwait;
    }

  his.sAwaito= f (thT parsinitat_(         *ingreak;
  =  BREAK:
  s.getTreeStartLocatio);
    }

  his.sAwaito= fis.sAwait;
    eak;
  ingreak;
 rtat, fun SE_CURLY f tinues*
   lizegtion_();Yingreak;
 st TemeopenlizeptaesiaowYtem_CURLYingreak;
  is*
   .lhbyction_ion_wart), ids } el.parseLhttps://bugs.ecmascript.org/sh_w_bug.cgi?id=381} el.parseLGtion_();sionrehent is er Initia
ssionrehent is )parseFunction_Gtion_();sionrehent is
nitiali
      ();
asonrehent isParam()=his.parseCsonrehent isPara@private
   *ingreak;
  =  BREAK:
  s.getTreeStartLocatio);
    }

    this.eat_gIdentifier_is();
 heckGeion_();sionrehent iss.parseBindingElementInitializ    debuges 


























asonrehent isParaz    debuges 


























ingreak;
 ));is, fun SE_CURLYFor
definemer Initializeropt
   *   Br Initializeropation;
tur . /**
   *For
definer s this.optseStric();
is.getTreeStartLocation_();lhs = tis();
  BREAK:
  ndefineation;
    if (tis();
  BREAK:
  ndefinePattern_();
     aratioonDesl
 c();liz; seeatioonhttp://wiki.ecmascript.org/doku.php?id=harmony:desl
 c();liz
rse/atioonSpi elMonkey is luch more lib = t i
 whers.ptrfis.ss
)) onK:
estemsaddeeption;
s,gfre
inamplr,iptrfis.ss [x, ([y, z])] but
   * teois.pnn()nK:
estems/s aoen'trfis.sed i
 tem g{Fomndio
 tem ES
   * wiki.STeStrimplrreeSrtLocac
 servaomvelyio
lyifis.ss K:
estems/s
   * at temetop-level of a.getTreeS.ititrreeSs. fun    is.getTree    arameterList(this.gee = thisdesl
 c();lizeieceeStartLocObjieris.getTree    a{
    var n StartLocionayis.getTree     name, funaLocionayis.getTree                    parametComputedProname, funaLocObjieris.getTree    a               parametCompument_);is, fun SE_CURLYndefineation;
mer InitiaObjierlizeropation;
tur . iasonaylizeropation;
tur . /**
   *ndefineation;
   arameterList(this.geratiis.getTreeree>name, funaratiis.getTreu *ndefines this.optseStric();
ionayis.getTreeStartLocation_();lhs = tis();
  BREAK:
  ionayis.getTreu *ndefines if (tis();
  BREAK:
  Objieris.getTreu *ndefines if aration(this.gsonaylizeropation;
 er Initia[]r Initia[k
definel  //  Param]r Initia[k
definel  //  Param, Elik;
 ee k
defineReral  //  ee k]} el.parseL
definel  //  Paramer InitiaElik;
 ee k
definel  //  r Initializeropl  //  Param, Elik;
 ee k
definel  //  r Inir InitElik;
 mer Initia,r InitiaElik;
 a,r IniFunction_ionaylizeropation;
   arameterList(this.geratiionayis.getTreeree>name, funaratiis.getTl  //  reu *ndefines this.orList(tu *ndefine ?.option   BREAK:
  ndefinel  //  re) :  BREAK:
  s.getTreeSt  //  re)name, funaratiis.getTReral  //  reu *ndefines this.orList(tu *ndefine ?.option   BREAK:
  ndefineReral  //  re) :  BREAK:
  s.getTreeSReral  //  re)n(laarati     srnayis.getTreu *ndefines  /**
   * @return {VariableStatement}
   * @private
   *i  //  s = rn {**
    this.eae
   N_SQUARE)() {   vs.geE)() {express(s.getTreeStartLocation_lvinitt_(OPEN_SQUAYie   parinitEND_OF_FILEthis.pushAStric= thirlik;
  thisi  //  s));isssssptseStric();
Rera_(
StartLocation_();.is.pushAthi  //  stToken_();
     is.getTReral  //  reu *ndefines ifieissssss.peekType_()ssElement_(thisthi  //  stToken_();
     is.getTl  //  reu *ndefines ifieisssss * Trailine cromas aoe not fis.sed i
 ption;
s
   *AthhhpeAnnotation = C     Yield = func    !his.getTr_(s.eat_N_SQUA, 1 this.pushAthth
   *    if (!this.optie_()s
tie_()s
tie_}
    }

    this.eat_N_SQUARE)() {
    var stsrnayis.getTs.parseBindingElementInitializ.i  //  s));is, fun SE_CURLYndefinel  //  Paramer InitiaElik;
 ee k
definel  //  r Initializeropl  //  Param, Elik;
 ee k
definel  //  r Ini /**
   *ndefinel  //  Paraisi  //  s)ssionIn
   *= thirlik;
  thisi  //  s));isssi  //  stToken_();
     ndefinel  //  re));
    expressionIn
  c          .is.pushAStric= thirlik;
  thisi  //  s));isssssi  //  stToken_();
     ndefinel  //  re));
    s.op, fun Function   //s temeelik;
 aee kprodumedExiaowYappendstat_(i   tem_CURLY{@code
i  //  s} aonaygfre
ivere)imptyeelik;
  } el.parseLDtTreeLosrnay}*i  //  s Temeaonayg   appendg  .r Ini /**
   *rlik;
  thisi  //  s).is.pusexpressionIn
  c          .is.pushAi  //  stTokenat_(END_Os.s.op, fun Functionndefinel  //  mer InitiaSineled Condefiner Initializeropation;
 en any addree } el.parseLSineled Condefinemer Initializeropt
   *   B en any addree } el.ationalsndefinel  //  re
    arameterList(this.getTrndefinePattern_();
e    a{
 his.getTr s.getTree    );is, fun SE_CURLYDtTreeLoen any addr=} in any addrnIf lefe out temein any addrnisr InitiaiiAsomma t)aowYais.sed.nIf seS.to en any addr.REQUIRED temoe   elsbe anr Initiaiiin any addr
   * Script or on_() {
    ret /**
   *ndefinel  //  rein any addrn= en any addr.OParseALn this.o    typeAnnotation, this.popAnnotations_()
        b   swi =  BREAK:
  Biefinel  //  
definer sE)() {   vin any addrn=  BREAK:
  Biefinel  //  en any addrrein any addrRE)() {
    var st
definel  //     return new FormalParameter(this.getT   *Athhhpn any addrRE)()arati     Biefinel  //  
definer s this.optseStric();
is.getTreeStartLocation_();lhs = tis();
  BREAK:
  ndefineation;
    if (tis();
  BREAK:
  ndefinePattern_();
     aratiK:
  Biefinel  //  en any addrrein any addrn= en any addr.OParseALn this.opeAnnotation = this.pa{
    var nin any addrn=== en any addr.REQUIRED .is.pushAis();
  BREAK:
  en any addrrei;
 deb}Uthis.
    vart_(    , fun FunctionndefineReral  //  mer Initia   F
defineI    *   B  ret /**
   *ndefineReral  //  re)  /**
   * @return {VariableStatement}
   * @private
}

    thiDOT_DOT_DOTsE)() {   vi    *   Bit_();
    }
ndefinePattern_();
      t
    var st art),is.getTl  //     return new FormalParameter(ti    *   B );is, fun SE_CURLYObjierlizeropation;
mer Initia{}r Initia{alizeroparAssityParam}r Initia{alizeroparAssityParam, }r Inir IniLlizeroparAssityParamer InitializeroparAssityr InitializeroparAssityParam, lizeroparAssityr Ini /**
   *Objieris.getTreu *ndefines  /**
   * @return {VariableStatement}
   * @private
   *i  //  s = rn {**
    this.eae
   ment_)E)() {   vs.geE)() {express(s.getTreeStartLocation_lvinitt_(OPEment_Yie   parinitEND_OF_FILEthis.pushAi  //  stToken_();
     is.getTarAssityreu *ndefines ifieisssar s!his.g
  c          t_(this.ps.peekType_}
    }

    this.eat_ment_)E)() {
    var stObjieris.getTs.parseBindingElementInitializ.i  //  s));is, fun SE_CURLYndefinearAssitymer InitiaSineled Condefiner InitiaarAssity.all :k
definel  //  r Inir InitSineled Condefinemer Initializeropt
   *   B en any addree } el.ation    is.getTarAssityreu *ndefines this.o    typeAnnotation, this.popAnnotations_()
        FunctionDeclPARENPrAssity.allns_()
        requtreCol
  = hall.  parinitLITERAL_PRe
 RTY_NAMEa{
    var n!hall.lrt = t     .isth  }
Keyword( Yield = funchall.lrt = t     .  parinitnd.type == {**
 ar srequtreCol
  {
 his.getTrhis_ [];this.pushAStrictDihis_ [];);
      }

i  //  tionDeclPARENPs.getTl  //  reu *ndefines);
      * TODO(arv): ReFunctObjieris.getTFthisYto lizeroparAssityr In) {
    var stObjieris.getTFthiss.parseBindingElementInitializ    debuges 
























Funcz.i  //  i;
 deb}Uthis.   ve parseLnall.lrt = t      {**
 ar s
   *sh  }
Mode_Yie      .isth  }
Keyword( is.pushA/
  pitialiRerervedPattern_();
euncti;
fier_ar su *ndefines this.o      b   swi = heck
defineI    *   B(nall.lpressio  l     ifieisss   vin any addrn=  BREAK:
  en any addr thistartLocati}NORMALn;r In) {
    var st
definel  //     return new FormalParameter(this.getT   *Athhhhhhhhhhhhhhhhhhhhhhhhhhhin any addrRE)() {}Uthis.   va.getTreeS.= heckI    *   BtartLocationall.lpressio  l     ifieis   vin any addrn=  BREAK:
  en any addr thistartLocati}NORMALn;r In)
    var sts.getTreeSt  //  s.parseBindingElementInitializ.a.getTreeSz    debuges 





















pn any addrRE)()arati     p.getTreeSation;
  =arameterList(this.geratiis.getTre   ifs if aration(this.gsonayp.getTreeSation;
[ this] er Initia[ Elik;
 ee ks.getTreeSReral  //  [? this]ee k]} el.tia[ s.getTreeSt  //  Para[? this]k]} el.tia[ s.getTreeSt  //  Para[? this]k, Elik;
 ee ks.getTreeSReral  //  [? this]ee k]} el.this.gs.getTreeSReral  //  [ this] er Initia   FDesl
 c();lizs.getTreeSTareBi[? this]} el.this.gs.getTreeSt  //  Para[ this] er Initias.getTreeSt ik;
 l  //  [? this]r Initias.getTreeSt  //  Para[? this]k, s.getTreeSt ik;
 l  //  [? this]r Inithis.gs.getTreeSt ik;
 l  //  [ this] er InitiaElik;
 ee ks.getTreeSl  //  [? this]r Inithis.gs.getTreeSt  //  [ this] er InitiaDesl
 c();lizs.getTreeSTareBi[? this] en any addr[In,? this]ee r Inithis.gDesl
 c();lizs.getTreeSTareBi[ this] er InitiaLeftHandSi; rClass = n[? this]r IniFunction_ionayp.getTreeSation;
  =arameterList(this.geratisrnayis.getTre   ifs if aratiK:
  s.getTreeSt  //  re) this.o    typeAnnotation, this.popAnnotations_()
        a.getTreeS.= his.geratiDesl
 c();lizs.getTreeSTareBir sE)() {   vin any addrn=  BREAK:
  en any addr thistartLocati}NORMALn;r In)
    var sts.getTreeSt  //  s.parseBindingElementInitializ.a.getTreeSz    debugpn any addrRE)()arati     Desl
 c();lizs.getTreeSTareBir s

  /**tart = this.getTreeStartLocation_();
  e
   tedPro       retrList(this.geratisrnayp.getTreeSation;
  = this._();
  e
   ment_       retrList(this.geratiObjierp.getTreeSation;
  = this.pan, c   *ingreak;
  =  BREAK:
  LeftHandSi; rClass = ns.);
    is();
  BREAas be@retursTootaes result);
  ingreak;
 )if aratiK:
  s.getTreeSReral  //  re)  /**
   * @return {VariableStatement}
   * @private
}

    thiDOT_DOT_DOTsE)() {   vi .= his.geratiDesl
 c();lizs.getTreeSTareBir sE)() {
    var st art),is.getTl  //     return new FormalParameter(ti  );is, fun SE_CURLYObjierp.getTreeSation;
[ this] er Initia{m}r Initia{ap.getTreeSarAssityPara[? this] }r Initia{ap.getTreeSarAssityPara[? this] , }r Inir IniLp.getTreeSarAssityPara[ this] er Initias.getTreeSarAssity[? this]r Initias.getTreeSarAssityPara[? this] , s.getTreeSarAssity[? this]r Inir IniLp.getTreeSarAssity[ this] er InitiaI    *   BRefeaesce[? this] en any addr[In,? this]ee r Ini iaarAssity.all :ks.getTreeSl  //  [? this]r Ini /**
   *Objierp.getTreeSation;
  =arameterList(this.geratiObjieris.getTre   ifs if aratiK:
  s.getTreeSarAssityre=arameterList(this.geratiis.getTarAssityre   ifs if aration(this.g eleD;
  art = tsr Inir IniL eleD;
  :er InitiaFull eleD;
 r Initia eleD;
 Ht),r Inir IniLFull eleD;
  :er Initia`a eleD;
 Characmalsee k`r Inir IniL eleD;
 Ht), :er Initia`a eleD;
 Characmalsee k${r Inir IniL eleD;
 SubstitumalPTail :er Initia eleD;
 Middl r Initia eleD;
 Tailr Inir IniL eleD;
 Middl  :er Initia}a eleD;
 Characmalsee k${r Inir IniL eleD;
 Tail :er Initia}a eleD;
 Characmalsee k`r Inir IniL eleD;
 Characmals :er Initia eleD;
 Characmala eleD;
 Characmalsee r Inir IniL eleD;
 Characmal :er InitiaSourc Characmal but not on  of ` oOp\ oOp$r Initia$a[lookaht), not {k]} el.tia\ EscapeSequescer InitiaLine f tinuati;
r IninctionDptElemeotation, i AssiandnctionDeclaration_() {
    return this.parseFunction_ eleD;
 art = t
 Assiand) this.opeAn this.peekType_teleD;
 art = ts)er_(iniY);
    BREAK:
  */
  parseSpreadE'`'_()
        @return Assiandc?.option  Assiand.xpressio !this :  BREAn, this.popAnnotations_()
        e parseLitera    if (!this.opti();
i  //  s = rn stieleD;
 art = tPaliliss. par.xpressio, l     ]()
    ptseS    .  par=== NO_SUBSTITUarse_TEMPLATs .is.pushAis();
 n stieleD;
 art = t result);
s.parseBindingElementInitializs.pushAthhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhAssiandz.i  //  s));isss}Uthis.// `abc$ /**
   * ingreak;
  =  BREAK:
  tartLocatio);
    i  //  stTokena stieleD;
 SubstitumalP ingreak;
 .xpressio  ingreak;
 )_()
    expressingreak;
 .  parinitSYNTAX_ERROR_TREEthis.pushAS parseLitera    ieleD;
 art = tif (!this.optie_ptseS    .  par=== ERROR {
 h    .  par=== END_OF_FILEts.pushAtheekTypeatementi  //  stTokena stieleD;
 art = tPaliliss. par.xpressio, l     is.optie_ptseS    .  par=== TEMPLATs_TAILts.pushAtheekTypeatementingreak;
  =  BREAK:
  tartLocatio);
      i  //  stTokena stieleD;
 SubstitumalP ingreak;
 .xpressio  ingreak;
 )_()isss}Uthis.is();
 n stieleD;
 art = t result);
s.parseBindingElementInitializs.pushAthhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhAssiandz.i  //  s));isaratiK:
  eeStAnnotement thisn this.opeAnnotatpeekType_teStsYiecnotat  t thisC_ [];this.pushAY);
    BREAK:
  cation_();
  ieecif       rt_(    , fun Functioncatisr Inir Ini cati:r Ini   PrimareOrUnalPTatir Ini   art), idTatir Ini    f sl
 c(orTatir Inir Ini PrimareOrUnalPTati:r Ini   PrimareTatir Ini   UnalPTatir Inir Ini PrimareTati:r Ini   P:
estemsaddeTatir Ini   P  break;
Tatir Ini   TatiRefeaescer Ini   ObjierTatir Ini   srnayTatir Ini   TupleTatir Ini   TatiQueryr Inir Ini P:
estemsaddeTati:r Ini   ( Tati )r IniparseLDeclaration_() {
    return this.parseFunction_ eStartt
  /**tart = this.getTreeStartLocation_();
  NEWes)
    
 is();
  BREAK:
  af sl
 c(orTatins_()
     reDoWhCompu(OPEN();
    );
  e
   ANGLses)
    ugis();
  BREAK:
  art), idcation_();
  ie
        @return {VariableStatement}
   * @private
   *i  //  T.getTreeStarARENPrimarecation_();
  Y);
    BREAK:
  */ idcatiSuffix_();
    i  //  T.ge)name, funaratiirimarecation_  /**
   * @return {VariableStatement}
   * @private
   *i  //  T.geE)() {tart = this.getTreeStartLocation_();
  VOIDes)
          e parseLitera    if (!this.optiiiiii  //  T.getTr var   break;
Tati   return new FormalParameter(tl     ifieissstheekTypeatement);
  nd.type ==es)
      tart = this.getTref (!thihv  uh(statementar  rseTr'any'es)
       reDoWh'nts ea)'es)
       reDoWh'number'es)
       reDoWh's     'es)
       reDoWh'symbol'es)
       r      e parseLitera    if (!this.optiiiiiiiiii  //  T.getTs.pushAthhhhhhhhh var   break;
Tati   return new FormalParameter(tl     ifieisssthsstheekTypeisssthssth)
          debuges 
i  //  T.getTreeStarARENTatiRefeaesce if (thisssss}      reteekTypeatement);
  TYPEOFes)
     
i  //  T.getTreeStarARENTatiQueryarameterifieissstheekTypeatement);
  e
   ment_       reti  //  T.getTreeStarARENObjierTati if (thissssseekTypeatement * TODO(arv): P:
estemsaddeTatir Inent * eDoWhCompu(OPEN()eatement)
          debugis();
  BREAK:
  */
  parseSpreadEiis.getTref (!thi_()isss}Uthis.is();
 his.geratisrnaycatiSuffix_();
    i  //  T.ge)name, funaratiTatiRefeaesce if  /**
   * @return {VariableStatement}
   * @private
   *teStNunctionDeclPARENTeStNunc@private
   *argss= at_(      ptseSis.getTr_(e
   ANGLs);his.pushA   vargss=  BREAK:
  eeStArguClass if (thisssis();
 n stiatiRefeaesce   return new FormalParameter(tleStNuncz.argsrn(laeb}U            eStNuncname, funarati*/ idcatiSuffix_();
    i  //  T.ge) this.opeAnnotation = BARethis.pushA   vteStsY= ri  //  T.ge] (thisss}

    thiBARe (thisss.<ParseTree>}
   * @p**teStstToken_();
     irimarecation__();
  his.ptse!his.g
  c   BARethis.pushAsssseekTypethisssss}      r}(thisssis();
 n st*/ idcati   return new FormalParameter(tleStsrn(laeb}U           i  //  T.geE)()arati     srnaycatiSuffix_();
    i  //  T.ge) this.o();
e parseLiteraportSpeciNoLak;T

   _();sElementsptseS    Yie      .  parametComputedProthis.pushAStrictDihie
   N_SQUARE)() {  }

    this.eat_N_SQUARE)() {iii  //  T.getTr varsrnaycatis.parseBindingElementInitializ.i  //  T.ge)namehis.is();
 his.geratisrnaycatiSuffix_();
    i  //  T.ge)namess}Uthis.is();
 i  //  T.geE)()arati     eeStArguClass if  /**
   * @return {VariableStatement}
   * @private
}

    thie
   ANGLs)ivate
   *argss= [ BREAK:
  cation_]E)() {expressnotation = C     this.pushAStrictDihis_    namehis.argstToken_();
     cation__();
  }Uthis.   ve parseLitera    ClotisnelesElementsptseS    .  parinits.eat_ANGLsthis.pushAY);
    BREAK:
  */
  parseSpreadEi    .  pa_()isss}Uthis.is();
 n stieStArguClasss.parseBindingElementInitializ.argsrn(laarati     af sl
 c(orTatins_  /**
   * @return {VariableStatement}
   * @private
}

    thiNEWlements   vteStP {Formalss=  BREAK:
  TeStP {Formals thisnivate
}

    thie
   gIdentments   vp {FormalPara =  BREAK:
  Forturn {Formals_();
    }

    this.eat_gIdentifier_}

    thiARmenpivate
   *is();
T.getTreeStarARENTati if (this this.checkaf sl
 c(orTati   return new FormalParameter(tleStn {Formalszs.pushAthhhhhhhhhhhhhhhhhhhhhhhhp {FormalPara,*is();
T.ge     aratioonObjierTati:
n  * ia{tieSt, tyee k}
rse/atioonieSt, ty:
n  * iaieStMemberLara ;ee r Ie/atioonieStMemberLara:
n  * iaieStMember
n  * iaieStMemberLara ;aieStMember
n rARENObjierTati if  /**
   * @return {VariableStatement}
   * @private
   *teStMembers = rn {**
    this.eae
   ment_)E)() {   vs.geE)() {expresshis.getTreeStMember_(s.getTreeStartLocation_lthis.pushASeStMemberstToken_();
     catiMember_(s.ges ifieisssar s!his.g
  c   SEMI_C_ [];this.pushAsss.peekType_()s(laeb}U    }

    this.eat_ment_)E)(this this.checkObjierTati   return new FormalParameter(tleStMembers name, funaLoccatiMember_(s.ges={ = th result.push(statement);
  NEWes)
    eDoWhCompu(OPEN();
    );
  e
   ANGLses)
    );
  e
   tedPro       r);
  nd.type ==es)
    );
  iTRING       r);
  NUMB==es)
      ions_.bl
        } )
          debugis();
 his.getTref (!thihisKeyword( n(laeb}U  aratiooncatiMember:
n  * iaarAssitySig _(ure
n  * iaa;llSig _(ure
n  * iaaf sl
 c(Sig _(ure
n  * iaI  exSig _(ure
n  * iaMethodSig _(ure
n      catiMember_(s.ges={ = th result.push(statement);
  NEWes)
    
 is();
  BREAK:
  af sl
 c(Sig _(ure  = this._();
  e
   (OPEN();
    );
  e
   ANGLses)
    ugis();
  BREAK:
  a;llSig _(ure  = this._();
  e
   tedPro       retrList(this.geratiI  exSig _(ureon_();
  ie
        @return {VariableStatement}
   * @private
   *prAssity.all =  BREAK:
  Lrt = tPrAssity.allns_()ate
   *is thtionDeclsync   QUESarse; {**
  .getTreeStartLocation_ementsptseS parametCompuANGLs {
 h parametCompugIdentYis.pushA   vc;llSig _(urec()=his.
   *a;llSig _(ure  = this._(
    var stMlthodSig _(ure   return new FormalParameter(tprAssity.allz    debuges 





















ps th,vc;llSig _(ure_();
  }Uthis.   veeStAnnotements=  BREAK:
  eeStAnnotement thisn (this this.checkarAssitySig _(ure   return new FormalParameter(tprAssity.allz    debuges 





















ps th,veeStAnnotementrn(laarati     a;llSig _(ure  =  /**
   * @return {VariableStatement}
   * @private
   *teStP {Formalss=  BREAK:
  TeStP {Formals thisnivate
}

    thie
   gIdentments   vp {FormalPara =  BREAK:
  Forturn {Formals_();
    }

    this.eat_gIdentifier_   *is();
T.getTreeStarARENTatiAnnotement thisn (this this.checka;llSig _(ure   return new FormalParameter(tleStn {Formalszs.pushAthhhhhhhhhhhhhhhhhhhhhhp {FormalPara,*is();
T.ge     aratiK:
  af sl
 c(Sig _(ure  =  /**
   * @return {VariableStatement}
   * @private
}

    thiNEWlements   vteStP {Formalss=  BREAK:
  TeStP {Formals thisnivate
}

    thie
   gIdentments   vp {FormalPara =  BREAK:
  Forturn {Formals_();
    }

    this.eat_gIdentifier_   *is();
T.getTreeStarARENTatiAnnotement thisn (this this.checkaf sl
 c(Sig _(ure   return new FormalParameter(tleStn {Formalszs.pushAthhhhhhhhhhhhhhhhhhhhhhhhhhhp {FormalPara,*is();
T.ge     aratiK:
  I  exSig _(ureon_  /**
   * @return {VariableStatement}
   * @private
}

    thie
   N_SQUARE)() {   vi .= his.gtDirdd,);
    StrictDihis_ [];);
      *teStNunc);
      *teStSreturn {VariableStatement}
   * @private
ptseStric();
i  break;
      ca's     'lthis.pushASeSt.all =  BREAtDirdd,'s     'l();
  }sElement_(thisSeSt.all =  BREAtDirdd,'number'= this.pan, c   *   exT.getTs.pushAth var   break;
Tati   return new FormalParteStSretur(tleStNunc);
    }

    this.eat_N_SQUARE)() {StrictDihis_ [];);
      *teStAnnotements=  BREAK:
  eeStisn (this this.checkI  exSig _(ure   return new FormalParameter(ti ,*   exT.gezs.pushAthhhhhhhhhhhhhhhhhhhhhhheeStAnnotementrn(laarati     art), idcation_  /**
   * @return {VariableStatement}
   * @private
   *teStP {Formalss=  BREAK:
  TeStP {Formals thisnivate
}

    thie
   gIdentments   vp {FormalPara =  BREAK:
  Forturn {Formals_();
    }

    this.eat_gIdentifier_}

    thiARmenpivate
   *is();
T.getTreeStarARENTati if (this this.checkart), idcati   return new FormalParameter(tleStn {Formalszs.pushAthhhhhhhhhhhhhhhhhhhhhp {FormalPara,*is();
T.ge     aratiK:
  TatiQueryarameterssionIn
 n_w 'NYI'    aratioonTeStP {Formals:
n  * ia<nTeStP {FormalPara >r Ie/atioonieStP {FormalPara:
n  * iaieStP {Formal
n  * iaieStP {FormalParam, ieStP {Formal
n  *atioonieStP {Formal:
n  * iat
   *   B af sl
ai  ee 
n  *atioonaf sl
ai  :
n  * iaextendstTatirfunaLoccatin {Formals_()arameterList(this.getTrhie
   ANGLs)ivataratiK:
  TatiP {Formals thisn this.opeAnnotation = e
   ANGLs);his.pushAY);
    BREAK:
  catin {Formals_();
    ieecif       rt_(    , funK:
  catin {Formals_()  /**
   * @return {VariableStatement}
   * @private
}

    thie
   ANGLs)ivate
   *p {Formalss= [ BREAK:
  catin {Formalon_]E)() {expressnotation = C     this.pushAStrictDihis_    namehis.p {FormalstToken_();
     catin {Formalon_);
    ieecif}

    this.eat_ANGLs)ivate
is();
 n stieStn {Formals   return new FormalParameter(tp {Formals)ivataratiK:
  TatiP {Formalon_  /**
   * @return {VariableStatement}
   * @private
   *i .= his.gtDirdd,);
      * intendsT.getTr t_(      ptseSis.gsync   EXTENDS) this.pushAintendsT.getTr BREAK:
  cation_();
  ieecif       r stieStn {Formal   return new FormalParameter(ti ,*intendsT.ges if aration(this.g   break;
Tati :er Initiaanyr Initianumberr Initiants r Initias     r InitDeclaration_() {
    return this.parseFunction_NFordOr   break;
Tatire) this.o    typeAnnotation, this.popAnnotations_()
    tart = this.getTref (!thihv  uh(statementrseTr'any'es)
    eDoWh'number'es)
    eDoWh'nts ea)'es)
    eDoWh's     'es)
     * voi .is haowled i
 pt
  caslhs = tti    e parseLitera    if (!this.optiiiii this.checkar break;
Tati   return new FormalParameter(tl     ifieisss)
          debugis();
  BREAK:
  TeStNunc@private
s.op, fun FunctionTati .all :er InitiaModuleOrTeStNuncr Inir InitModuleOrTeStNunc :er Initiat
   *   Br InitiaModuleNunc .at
   *   Br Inir InitModule.all :er InitiaModuleOrTeStNuncr Inir InitDeclaration_() {
    return this.parseFunction_ eStNunc@pr  /**
   * @return {VariableStatement}
   * @private
   *i .= his.gtDirdd,);
      * SeSt.all = r stieSt.all   return new FormalParameter(tat_(odid);
 debexpressionIn
  c   PERIODethis.pushA   vllmber.all =  BREAtDirdNunc@private
  SeSt.all = r stieSt.all   return new FormalParameter(tSeSt.allzs.pushAllmber.allrn(laeb}U            eStNuncname, fun Functioni  erfaceat
   *   B catin {Formals_ee kI  erfaceEntendsClause_ee r Ini ia  ObjierTatir Inir Ini I  erfaceEntendsClauseer InitiaextendstClassOrI  erfaceTatiPara} el.parseL lassOrI  erfaceTatiParaer Initia lassOrI  erfaceTatir Initia lassOrI  erfaceTatiParam,  lassOrI  erfaceTatir IniparseL lassOrI  erfaceTatier Initia ytiRefeaescer IniFunction_I  erfaceDecl {F  * @pr  /**
   * @return {VariableStatement}
   * @private
}

    thiINTERFACs)ivate
   *FunctionDeclsyncF@private
   *teStP {Formalss=  BREAK:
  TeStP {Formals thisn
      * intendsClause      ptseSis.gsync   EXTENDS)this.pushAintendsClausen=  BREAK:
  en erfaceEntendsClause_.);
    ssElement_(thisintendsClausen= rn {**
 pan, c   *objierTatitTreeStarARENObjierTati if (this this.checkI  erfaceDecl {F  * s.parseBindingElementInitializs.pushAthFuncz.leStn {FormalszsintendsClause,*objierTati     aratiK:
  I  erfaceEntendsClause_.)  /**
   * res   s= [ BREAK:
  catiRefeaesce if]E)() {expressnotat
  c          .is.pushAres   tToken_();
     catiRefeaesce ifrn(laeb}U    s this.cres   name, fun FunctionAnnotementssintencatir Inir InitDeclaration_() {
    return this.parseFunction_AnnotemedDecl {F  * s_(tion   ModuleItem)ssionIn
   *=okeAnnotementsns_()
        decl {F  * ivate
   *teSttTreeStartLocation_ementsptsetion   ModuleItem)ssionIn  decl {F  * tTreeStarARENModuleItemdEi    ifieisssElement_(thisdecl {F  * tTreeStarARENStitrreeSParaItemdEi    ifieiss     ptseSis.gannotementsntlengtht> 0;his.pushAY);
    BREAK:
  Syntaxzer_(ex'Unsupiali.lhannotemed ingreak;
 'rn(laeb}U           decl {F  * ivatarati     snnotementsns_  /**
   * annotementss= rn {**
 expressnotat
  c   ATt(statementannotementstToken_();
     pnnotement ifrn(laeb}U           annotementsivatarati okeAnnotementsns_ssionIn
   *annotementsn =  BREAK:
  snnotementsns_()atarati opsnnotementsns_  /**
   * annotementss= 
   *annotementsn;ionIn
   *annotementsn = rn {**
        annotementsivatarati     pnnotement if  /**
   * @return {VariableStatement}
   * @private
   *ingreak;
  =  BREAK:
  Mlmber result);
NoNews.) (type   *argss= at_(       ptseSis.getTr_(e
   gIdent atementargss=  BREAK:
  ArguClass if ((this this.checkpnnotements.parseBindingElementInitializ.ingreak;
 z.argsrn(laaratioSE_CURLY f suCl asetseVarlyrimplicit) semi-col
 . Rtialispasiier_( ptsa semi-col
 nctionis not grealas } el.parseLDeclarativoi    return this.parseFunc
  PseVarleImplicitSemiCol
  if  /**
   * e parseLiteraportSpeciNoLak;T

   _();sElementsptse!tunctis.pushAis();
()
    tart = th    .  pa_statementrseTrSEMI_C_ []();
    } 
tera    if (!this.optiiiii this.;atementrseTrEND_OF_FILEes)
    eDoWhs.eat_ment_     debugis();
();
  }Uthis.
teraitializer_(ex'Semi-col
  
  parse'rn(laaratioSE_CURLYRclaras l
   ptsanrimplicit );Yinglicit semi col
  is at temecur
est xpressio } el.parseLDeclaratints ea)   return this.parseFunctortImplicitSemiCol
  if  /**
 tart = this.getTreeStartLocation_();
  SEMI_C_ []();
    eDoWhs.eat_ment_     debrseTrEND_OF_FILEes)
      ions_.bl
        }/**
   * e parseLiteraportSpeciNoLak;T

   _();sElementsions_.bl parsenitat_(    aratioSE_CURLY f suCls teme    bl parsptsit is of temecifier.lheeSt. Otemowise eclaras at_(
   * SNiver rtialispier_(s } el.parseLDtTreeLoIdentifie}o
  parseSpreaTatir InitDeclaratiIdent}iTemecs suCldbl par, );Yat_(iif teme    bl parsps not of temecifier.lheeSt.  return this.parseFunc
   thisi  parseSpreaTatin this.opeAnnotation = i  parseSpreaTatin)er_(iniY);
    BREA    if (!this.opti       rt_(    , fun FunctionShalihaowgfre
notat
   thisnd.type ==;} el.parseLDeclaratiI; i++) {
        return this.parseFunc
  Id thisn this.orList(this.getTrhind.type ==; ?onDeclsyncF@pr : rt_(    , fun FunctionShalihaowgfre
notat
  isnd.type ==;} el.LDtTreeLos     =}o
  parseparseLDeclaratiI; i++) {
        return this.parseFunc
  Id= i  parseseLunbreak;
f  /**
   * e parseLitera    if (!this.optiptse!tunctihis.pushA) {
i  parsets.pushAth
teraitializer_(exhis.getTref (!thi, `i  parses'${i  parse}'`SQUARpeeb       rt_(      }Uthis.ptseS    .  par=== nd.type ==; is.pushA) {
i  parseYie      .v  uhriniti  parsets.pushAth
teraitializ  parsezer_(ext par,ti  parsetpeatementions_.bl par      }Uthis.ptseS    .isth  }
Keyword( ihis.pushA) {
 terash  }
Mode_>}
   * @p**tteraitialiRerervedPattern_();
euncti;
* @p**ssElement_(thisth// Usesanri
   *   B l parspnstt), becausenit is l
ear.lhas such andnctihisth// tter simpli   s temetransfreters
   *Athhh this.checkI; i++) {
     s. par.xpressio, l    .  pa_()isss()s(laeb}sElement_(thisSteraitializ  parsezer_(ext par,ti  parse {
 'i
   *   B'rn(laeb}Umentsions_.bl par    , fun FunctionEaispasii
   *   B re
keyword. Equthilest to e
   *   B.all i
 tem s pa } el.parseLDeclarati        return this.parseFunc
  IdNunc@pr  /**
   * tseLitera    if (!this.optiptset.  parin nd.type ==; is.pushA) {
!thisKeyword( >}
   * @p**tteraitializ  parsezer_(ext, 'i
   *   B'rn(laebpeeb       rt_(       r}(thisssis();
 n stI; i++) {
     s..xpressio, l.i    ifieiss     ions_.bl    aratioSE_CURLY f suCls teme    bl par.nIf temecs suCldbl parsps not of temecifier.lheeSt_CURLYthen itialipasiier_( aowg       rt_(. Otemowise eclara temecs suCldbl par } el.parseLDtTreeLoIdentifie}o
  parseSpreaTatir InitDeclaratiIdent}iTemecs suCldbl par, );Yat_(iif teme    bl parsps not ofr Init@p**ttmecifier.lheeSt.  return this.parseFunc
  isi  parseSpreaTatin this.o  * e parseLitera    if (!this.optiptseS    .  parino
  parseSpreaTati)ent_(thisSteraitializ  parsezer_(ext par,ti  parseSpreaTati)QUARpeeb       rt_(      }Uentsions_.bl par    , fun FunctionIf teme    bl parsmat =ls temegivarsSpreaTatin on_( cf suCls temetunctnctionaowg      s l
  .parseFunc
  c   i  parseSpreaTatin this.opeAnnotation = i  parseSpreaTatin)ent_(thisStera    if (!this.optiiiions_.bl
        }/**
 ions_.b   ifn(laaratioSE_CURLYRcialipa 'X'ecifier.lhier_( llnsage.parseLDtTreeLoIdent}bl parsTemelpressio to itialiptemellnsage at.parseLDtTreeLoObjier}o
  parsesTemeStengeStat waso
  parse } el.parseLDeclarativoi    return this.parseFuncitializ  parsezer_(ext par,ti  parsetssionIn
   *itializer_(ext par, `pecifier.lhes.opt${es.op}`SQUARaratioSE_CURLYRclaras aaSourc Pseissio fre
noe @returof a K:
   l
ereStat @retus at temecur
est xpressio } el.parseLDeclaratiSourc Pseissio   return this.parseFuncableStatement}
   * @pr this.orList(this.getTref (!thihxpressio !thisQUARaratioSE_CURLYRclaras aaSourc Pseissio fre
noe endgof a K:
   l
ereStat endstat temecur
est xpressio } el.parseLDeclaratiSourc Pseissio   return this.parseFuncableStaEndt}
   * @pr this.orList(this.gscann();.las if (!hxpressio endQUARaratioSE_CURLYRclaras aaSourc Range fre
a K:
   l
ereStat @retus at {@retu}naowgendstat temecur
est xpressio } el.parseLDeclaratiSourc Range   return this.parseFuncableStagElementInitiali this.orList(tr st ourc Range();
    lparseBindinEndt}
   * @prSQUARaratihaowlearom/   rangei /**
   * TODO(arv): Attach    t
erenodes
   aratioSE_CURLY f suCls teme    bl parsaowg      s it. Wi_(i       ae  ver e  swi sl
eam ofr InitEND_OF_FILEtat temeendgof temefpressovc;llalssdon'trhav      =lck fre
EOFYinglicitly } el.parseLif (!izswi _( cf t   ua(. Stera    if (!thi wi_(iniver rt     aeregul  *ingreak;
  lrt = t } el.parseLDeclarati        return this.parseFunc    if (!thi this.orList(this.gscann();.    if (!(rn(laaratioSE_CURLY f suCls aeregul  *ingreak;
  lrt = tbl parsaowg      s it.} el.parseLDeclaratiart = tif (!   return this.parseFunc    Regul   result);
art = tif (!thi this.orList(this.gscann();.    Regul   result);
art = tif (!(rn(laarati    ieleD;
 art = tif (!thi this.orList(this.gscann();.    ieleD;
 art = tif (!(rn(laarati    ClotisnelesEl this.orList(this.gscann();.    Clotisnele(rn(laaratiisAtEndEl this.orList(this.gscann();.isAtEndEln(laaratioSE_CURLYRclaras l
   ptstemeindex-the    bl parsps of temecifier.lheeSt. Does not cf suCl anybl pars } el.parseLDtTreeLoIdentifie}o
  parseSatir InitDtTreeLonumber=i Ast_indexparseLDeclaratints ea)   return this.parseFunctort= i  parseSatin Ast_indexi /**
   * Too hot fre
)
     .p {Formalsthis.orList(this.getTref (!thAst_indexi.  par=== i  parseSatin(laaratioSE_CURLYRclaras lemeIdentifie of temeindex-the    bl par. Does not cf suCl anybl pars } el.parseLDeclarati     ifie}  return this.parseFunctortTatire) this.orList(this.getTref (!thihtatin(laaratioSE_CURLYRclaras lemeindex-the    bl par. Does not cf suCl anybl pars } el.parseLDeclarati     }  return this.parseFunctortTf (!thAst_indexi /**
   * Too hot fre
)
     .p {Formalsthis.orList(this.gscann();.tortTf (!hAst_indexin(laaratioSE_CURLYRclaras lemeindex-the    bl par. Does not ais.s anyblin   

   _();_CURLYbefore teme    bl par.nDoes not cf suCl anybl pars STeStreclaras at_( pt_CURLYnobl parswasofoundYbefore teme    blin   

   _(); } el.parseLDeclarati     }  return this.parseFunctortTf (!NoLak;T

   _();sEl this.orList(this.gscann();.tortTf (!NoLak;T

   _();Eln(laaratioSE_CURLYRcialispasiier_( llnsage at aegivarsl par } el.tDtTreeLotraceur.util.Sourc Pse  * |Ident}bl parsTemelpressio to itiali} el.tonIn
 mellnsage at.parseLDtTreeLos     }ellnsage T mellnsage to itialipin       .fretat @ryle } el.parseLDeclarativoi    return this.parseFuncitializer_(ex...argsr this.opeAnargstlengtht== 1this.pushAStricter_(Rciali();.itializer_((his.gscann();.eBiPseissio(iz.args[0] ifieisssElement_(this  * lpressio =.args[0]s.optiiipeAnlpressio pnstanceof Tunctihis.pushA  lpressio =.xpressio xpressio       r}(thisssStricter_(Rciali();.itializer_((xpressio !thisz.args[1] ifieiss   aratiitialiRerervedPattern_();
eunctissionIn
   *itializer_(ext par, `${es.ophtati} is acreservedii
   *   B`SQUARar}
                                                                                      